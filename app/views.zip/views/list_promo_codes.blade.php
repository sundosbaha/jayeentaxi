@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-12 col-sm-12">
        <a id="addpromo" href="{{ URL::Route('AdminPromoAdd') }}">
            <button class="btn btn-flat btn-block btn-success" id="newpromo" type="button" style="box-shadow: unset !important;">{{ trans('customize.add_promo_code'); }}</button></a>
        <br/>
    </div>
</div>
<div class="col-md-6 col-sm-12">
    <div class="box box-danger">
        <form method="get" action="{{ URL::Route('/admin/sortpromo') }}">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.sort') }}</h3>
            </div>
            <div class="box-body row">
                <div class="col-md-6 col-sm-12">
                    <select id="sortdrop" class="form-control" name="type">
                        <option value="promoid" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'promoid') {
                            echo 'selected="selected"';
                        }
                        ?> id="promoid">{{ trans('customize.promo_code'),' ',strtoupper(trans('customize.id')) }}</option>
                        <option value="promo" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'promo') {
                            echo 'selected="selected"';
                        }
                        ?> id="promo">{{ trans('customize.promo_code') }}</option>
                        <option value="uses" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'uses') {
                            echo 'selected="selected"';
                        }
                        ?> id="promovalue">{{ trans('customize.uses_remaining') }}</option>
                    </select>
                    <br>
                </div>
                <div class="col-md-6 col-sm-12">
                    <select id="sortdroporder" class="form-control" name="valu">
                        <option value="asc" <?php
                        if (isset($_GET['valu']) && $_GET['valu'] == 'asc') {
                            echo 'selected="selected"';
                        }
                        ?> id="asc">{{trans('customize.ascending')}}</option>
                        <option value="desc" <?php
                        if (isset($_GET['valu']) && $_GET['valu'] == 'desc') {
                            echo 'selected="selected"';
                        }
                        ?> id="desc">{{trans('customize.descending')}}</option>
                    </select>
                    <br>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" id="btnsort" class="btn btn-flat btn-block btn-success">{{ trans('customize.sort') }}</button>
            </div>
        </form>
    </div>
</div>
<div class="col-md-6 col-sm-12">
    <div class="box box-danger">
        <form method="get" action="{{ URL::Route('/admin/searchpromo') }}">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.filter') }}</h3>
            </div>
            <div class="box-body row">

                <div class="col-md-6 col-sm-12">

                    <select class="form-control" id="searchdrop" name="type">
                        <option value="promo_id" id="promo_id">{{ trans('customize.promo_code'),' ',strtoupper(trans('customize.id')) }}</option>
                        <option value="promo_name" id="promo_name">{{ trans('customize.promo_code'),' ',(trans('customize.name')) }}</option>
                        <option value="promo_type" id="promo_type">{{ trans('customize.promo_code'),' ',(trans('customize.type')) }}</option>
                        <option value="promo_state" id="promo_state">{{ trans('customize.promo_code_state') }}</option>
                    </select>
                    <br>
                </div>
                <div class="col-md-6 col-sm-12">
                    <input class="form-control" type="text" name="valu" id="insearch" placeholder="{{ trans('customize.keyword') }}"/>
                    <br>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" id="btnsearch" class="btn btn-flat btn-block btn-success">{{ trans('customize.search') }}</button>
            </div>
        </form>
    </div>
</div>
<div class="box box-info tbl-box">
    <div align="left" id="paglink"><?php echo $promo_codes->appends(array('type' => Session::get('type'), 'valu' => Session::get('valu')))->links(); ?></div>
    <table class="table table-bordered">
        <tbody>
            <tr>
                <th>{{ trans('customize.id') }}</th>
                <th>{{ trans('customize.promo_code') }}</th>
                <th>{{ trans('customize.value') }}</th>
                <th>{{ trans('customize.uses_remaining') }}</th>
                <th>{{ trans('customize.states') }}</th>
                <th>{{ trans('customize.is_expired') }}</th>
                <th>{{ trans('customize.start'),' ', trans('customize.date') }}</th>
                <th>{{ trans('customize.expiry'), ' ', trans('customize.date')   }}</th>
                <th style="width: 105px;">{{ trans('customize.actions') }}</th>
            </tr>
            <?php foreach ($promo_codes as $promo) { ?>
                <tr>
                    <td><?= $promo->id ?></td>
                    <td><?= $promo->coupon_code ?></td>
                    <td><?php
                        if ($promo->type == 1) {
                            echo $promo->value . " %";
                        } elseif ($promo->type == 2) {
                            echo "$ " . $promo->value;
                        }
                        ?></td>
                    <td><?= $promo->uses ?></td>
                    <td><?php
                        if ($promo->state == 1) {
                            echo "Active";
                        } elseif ($promo->state == 0) {
                            echo "Expired";
                        } elseif ($promo->state == 2) {
                            echo "Deactivated";
                        } elseif ($promo->state == 3) {
                            echo "Max Limit Reached";
                        }
                        ?></td>
                    <td>
                        <?php
                        if (date("Y-m-d H:i:s") < date("Y-m-d H:i:s", strtotime(trim($promo->start_date)))) {
                            echo "<span class='badge bg-blue'>Inactive</span>";
                        } else if (date("Y-m-d H:i:s") >= date("Y-m-d H:i:s", strtotime(trim($promo->expiry)))) {
                            echo "<span class='badge bg-red'>Expired</span>";
                        } else {
                            echo "<span class='badge bg-green'>Active</span>";
                        }
                        ?>
                    </td>
                    <td><?= date("d M Y g:i:s A", strtotime(trim($promo->start_date))) ?></td>
                    <td><?= date("d M Y g:i:s A", strtotime(trim($promo->expiry))) ?></td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-flat btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                                {{ trans('customize.actions') }}
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                <li role="presentation"><a role="menuitem" tabindex="-1" id="edit" href="{{ URL::Route('AdminPromoCodeEdit',$promo->id) }}">{{ trans('customize.edit'),' ', trans('customize.promo_code') }}</a></li>
                                <?php if ($promo->state == 1) { ?>
                                    <li role="presentation"><a role="menuitem" tabindex="-1" id="edit" href="{{ URL::Route('AdminPromoCodeDeactivate',$promo->id) }}">{{ trans('customize.deactivate') }}</a></li>
                                <?php } elseif ($promo->state == 2) { ?>
                                    <li role="presentation"><a role="menuitem" tabindex="-1" id="edit" href="{{ URL::Route('AdminPromoCodeActivate',$promo->id) }}">{{ trans('customize.activate') }}</a></li>
                                <?php } ?>
                                <!--li role="presentation"><a role="menuitem" tabindex="-1" id="history" href="">View History</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" id="coupon" href="">Delete</a></li-->
                            </ul>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <div align="left" id="paglink"><?php echo $promo_codes->appends(array('type' => Session::get('type'), 'valu' => Session::get('valu')))->links(); ?></div>
</div>
<?php
if ($success == 1) {
    ?>
    <script type="text/javascript">
        alert('You can\'t add duplicate promotional code');
    </script>
<?php } ?>
<?php if ($success == 2) { ?>
    <script type="text/javascript">
        alert('Sorry Something went Wrong');
    </script>
<?php }
?>
@stop
