@extends('layout')

@section('content')

<div class="row third-portion">
    <div class="tab-content">
        <div class="tab-pane fade" id="option3">
            <div class="row tab-content-caption">
                <div class="container">
                    <div class="col-md-10 big-text">
                        <p></p>
                    </div>
                    
                </div>
            </div>
            
            <div class="row editable-content-div">
             
            <center>Requested Page Not Found</center>
                
               
            </div>
            <!--</form>-->
        </div>
    </div>
</div>



@stop