<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Welcome</title>
    <style type="text/css" media="screen">

        .ExternalClass * {line-height: 100%}

        /* Début style responsive (via media queries) */

        @media only screen and (max-width: 480px) {
            *[id=email-penrose-conteneur] {width: 100% !important;}
            table[class=resp-full-table] {width: 100%!important; clear: both;}
            td[class=resp-full-td] {width: 100%!important; clear: both;}
            img[class="email-penrose-img-header"] {width:100% !important; max-width: 340px !important;}
        }

        /* Fin style responsive */

    </style>

</head>
<body style="background-color:#ecf0f1">
<div align="center" style="background-color:#ecf0f1;">

    <!-- Début en-tête -->
    <table id="email-penrose-conteneur" width="660" align="center" style="padding:20px 0px;" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td>
                <table width="660" class="resp-full-table" align="center" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="50%" style="text-align:center;">
                            <h2 style="font-size: 25px;font-family: 'Helvetica Neue', helvetica, arial, sans-serif;font-weight: bold;color: #6B6B6B;margin: 0;">You Are Successfully login</h2></a>
                        </td>

                    </tr>
                </table>
            </td>

        </tr>
        <tr>
<td>
            <table width="660" class="resp-full-table" align="center" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="50%" style="text-align:center;">
                        <table align="right" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <h6 style="font-size: 20px;font-family: 'Helvetica Neue', helvetica, arial, sans-serif;font-weight: bold;color: #6B6B6B;margin: 0;">Now you can login with your App</h6>
                            </tr>
                        </table>
                    </td></td>
                </tr>
            </table>
</td>

        </tr>

    </table>
    </div>
</body>
</html>


