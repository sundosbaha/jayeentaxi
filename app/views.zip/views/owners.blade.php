@extends('layout')

@section('content')
@if(Session::has('msg'))
<div class="alert alert-success"><b><?php
        echo Session::get('msg');
        Session::put('msg', NULL);
        ?></b></div>
@endif
<div class="col-md-6 col-sm-12">

    <div class="box box-danger">

        <form method="get" action="{{ URL::Route('/admin/sortur') }}">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.sort') }}</h3>
            </div>
            <div class="box-body row">

                <div class="col-md-6 col-sm-12">


                    <select id="sortdrop" class="form-control" name="type">
                        <option value="userid" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'userid') {
                            echo 'selected="selected"';
                        }
                        ?> id="provid">{{ trans('customize.User'),' ',strtoupper(trans('customize.id'))}} </option>
                        <option value="username" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'username') {
                            echo 'selected="selected"';
                        }
                        ?> id="pvname">{{ trans('customize.User'),' ',trans('customize.name')}}</option>
                        <option value="useremail" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'useremail') {
                            echo 'selected="selected"';
                        }
                        ?> id="pvemail">{{ trans('customize.User'),' ',trans('customize.email')}}</option>
                    </select>

                    <br>
                </div>
                <div class="col-md-6 col-sm-12">

                    <select id="sortdroporder" class="form-control" name="valu">
                        <option value="asc" <?php
                        if (isset($_GET['valu']) && $_GET['valu'] == 'asc') {
                            echo 'selected="selected"';
                        }
                        ?> id="asc">{{trans('customize.ascending')}}</option>
                        <option value="desc" <?php
                        if (isset($_GET['valu']) && $_GET['valu'] == 'desc') {
                            echo 'selected="selected"';
                        }
                        ?> id="desc">{{trans('customize.descending')}}</option>
                    </select>

                    <br>
                </div>

            </div>

            <div class="box-footer">


                <button type="submit" id="btnsort" class="btn btn-flat btn-block btn-success">{{ trans('customize.sort') }}</button>
                <button type="submit" id="btnsort" name="submit" class="btn btn-flat btn-block btn-success" value="Download_Report">{{ trans('customize.download'),' ',trans('customize.report') }}</button>
            </div>
        </form>

    </div>
</div>


<div class="col-md-6 col-sm-12">

    <div class="box box-danger">

        <form method="get" action="{{ URL::Route('/admin/searchur') }}">
            <div class="box-header">
                <h3 class="box-title">Filter</h3>
            </div>
            <div class="box-body row">

                <div class="col-md-6 col-sm-12">

                    <select class="form-control" id="searchdrop" name="filter_type">
                        <option value="userid" id="userid" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'userid') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.User'),' ',strtoupper(trans('customize.id'))}}</option>
                        <option value="username" id="username" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'username') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.User'),' ',trans('customize.name')}}</option>
                        <option value="useremail" id="useremail" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'useremail') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.User'),' ',trans('customize.email')}}</option>
                        <option value="useraddress" id="useraddress" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'useraddress') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.User'),' ',trans('customize.address')}}</option>
                    </select>


                    <br>
                </div>
                <div class="col-md-6 col-sm-12">
                    <input class="form-control" type="text" name="filter_valu" value="<?php echo (!empty($_GET['filter_valu']) ? $_GET['filter_valu'] : '');?>" id="insearch" placeholder="{{ trans('customize.keyword')}}"/>
                    <br>
                </div>

            </div>

            <div class="box-footer">

                <button type="submit" id="btnsearch" class="btn btn-flat btn-block btn-success">{{ trans('customize.search') }}</button>
                <button type="submit" id="btnsearch" name="submit" class="btn btn-flat btn-block btn-success" value="Download_Report">{{ trans('customize.download'),' ',trans('customize.report') }}</button>
           </div>
        </form>

    </div>
</div>



<div class="box box-info tbl-box">
    <div align="left" id="paglink"><?php echo $owners->appends(array('type' => Session::get('type'), 'valu' => Session::get('valu')))->links(); ?></div>
    <table class="table table-bordered">
        <tbody>
            <tr>
                <th>{{ strtoupper(trans('customize.id')); }}</th>
                <th>{{ trans('customize.name') }}</th>
                <th>{{ trans('customize.email') }}</th>
                <th>{{ trans('customize.phone') }}</th>
                <th>{{ trans('customize.address') }}</th>
                <th>{{ trans('customize.state') }}</th>
                <th>{{ trans('customize.zip_Code') }}</th>
                <th>{{ trans('customize.debt') }}</th>
                <th>{{ trans('customize.reffered_by') }}</th>
                <th>{{ trans('customize.actions') }}</th>



            </tr>

            <?php foreach ($owners as $owner) { ?>
                <tr>
                    <td><?= $owner->id ?></td>
                    <td><?php echo $owner->first_name . " " . $owner->last_name; ?> </td>
                    <td><?php $half=explode('@',$owner->email); echo "xxxx@".end($half);?></td>
                    <td><?php  $first=substr($owner->phone,0,4); echo $first."xxxxx"; ?></td>
                    <td>
                        <?php
                        if ($owner->address) {
                            echo $owner->address;
                        } else {
                            echo "<span class='badge bg-red'>" . Config::get('app.blank_fiend_val') . "</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($owner->state) {
                            echo $owner->state;
                        } else {
                            echo "<span class='badge bg-red'>" . Config::get('app.blank_fiend_val') . "</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($owner->zipcode) {
                            echo $owner->zipcode;
                        } else {
                            echo "<span class='badge bg-red'>" . Config::get('app.blank_fiend_val') . "</span>";
                        }
                        ?>
                    </td>
                    <td><?= sprintf2($owner->debt, 2) ?></td>
                    <?php
                    $refer = Owner::where('id', $owner->referred_by)->first();
                    if ($refer) {
                        $referred = $refer->first_name . " " . $refer->last_name;
                    } else {
                        $referred = "None";
                    }
                    ?>
                    <td><?php echo $referred; ?></td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-flat btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                                {{ trans('customize.actions') }}
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                <li role="presentation"><a role="menuitem" tabindex="-1" id="edit" href="{{ URL::Route('AdminUserEdit', $owner->id) }}">{{trans('customize.edit'),' ',trans('customize.User') }}</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" id="history" href="{{ URL::Route('AdminUserHistory',$owner->id) }}">{{trans('customize.view'),' ',trans('customize.history')}}</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" id="coupon" href="{{ URL::Route('AdminUserReferral', $owner->id) }}">{{trans('customize.coupon'),' ',trans('customize.details')}}</a></li>
                                <?php
                                $check = Requests::where('owner_id', '=', $owner->id)->where('is_cancelled', '<>', '1')->get()->count(); //print_r($check);
                                if ($check == 0) {
                                    ?>
                                    <li role="presentation"><a role="menuitem" tabindex="-1" id="add_req" href="{{ URL::Route('AdminAddRequest', $owner->id) }}">{{ trans('customize.add_request') }}</a></li>
    <?php } ?>
                                <li role="presentation"><a role="menuitem" tabindex="-1" id="add_req" href="{{ URL::Route('AdminDeleteUser', $owner->id) }}">{{ trans('customize.delete') }}</a></li>
                            </ul>
                        </div>
                    </td>
                </tr>
<?php } ?>
        </tbody>
    </table>

    <div align="left" id="paglink"><?php echo $owners->appends(array('type' => Session::get('type'), 'valu' => Session::get('valu')))->links(); ?></div>




</div>

<style type="text/css">

    #btnsort {
        width: 49% !important;
        left: 0% !important;
    }
    #btnsearch, .btn-warning {
        width: 49% !important;
        left: 0% !important;
    }

</style>


@stop