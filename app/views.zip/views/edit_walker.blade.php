@extends('layout')
@section('content')


    <?php


    $license_img="";
    $license_expiry_date="";
    $certificate_img="";
    $certificate_expiry_date="";
    $insurance_img="";
    $insurance_expiry_date="";
    $inspection_img="";
    $license_expiry_date="";


if(!empty($walk_document)){
    foreach($walk_document as $wd){
                if($wd->comment_key==1){
                    //$license_img_name;
                    $license_img=$wd->image;
                    $license_expiry_date=$wd->expiry_date;
                }if($wd->comment_key==2){
                    $certificate_img=$wd->image;
                    $certificate_expiry_date=$wd->expiry_date;
                }if($wd->comment_key==3){
                    $insurance_img=$wd->image;
                    $insurance_expiry_date=$wd->expiry_date;
                }if($wd->comment_key==4){
                    $inspection_img=$wd->image;
                    $inspection_expiry_date=$wd->expiry_date;
                }

            }
}
    ?>



    <?php $counter = 1; ?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title">
                <?= $title ?>
            </h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form method="post" id="main_form" action="{{ URL::Route('AdminProviderUpdate')}}"  enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $ids ?>">
            <div class="box-body">
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>
                                <h3>{{ trans('customize.personal'),' ',trans('customize.details') }}
                                </h3>
                            </label>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label>{{ trans('customize.first'),' ',trans('customize.name') }}
                                </label>

                                <input type="text" class="form-control" name="first_name" value="<?= $walker->first_name ?>" placeholder="{{ trans('customize.first'),' ',trans('customize.name') }}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.last'),' ',trans('customize.name') }}
                                </label>
                                <input class="form-control" type="text" name="last_name" value="<?= $walker->last_name ?>" placeholder="{{ trans('customize.last'),' ',trans('customize.name') }}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.email')}}
                                </label>
                                <input class="form-control" type="email" name="email" value="<?=
                                $walker->email ?>" placeholder="{{ trans('customize.email')}}" readonly >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.email')}}
                                </label>
                                <input class="form-control" type="text" name="bio" value="<?= $walker->bio ?>" placeholder="{{ trans('customize.bio')}}">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>
                                <h3>{{ trans('customize.identity')}}
                                </h3>
                            </label>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label>{{ trans('customize.profile'),' ',trans('customize.image') }}
                                </label>
                                <input  type="file" name="pic" >
                                <br>
                                <?php if(!empty($walker->picture)){ ?>
                                <img src="<?= $walker->picture; ?>" height="50" width="50">
                                <?php } ?>
                                <br>
                                <p class="help-block">{{ trans('customize.upload_image_format') }}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>
                                <h3>{{ trans('customize.address'),' ',trans('customize.details') }}</h3>
                            </label>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label>{{ trans('customize.address')}}
                                </label>
                                <input class="form-control" type="text" name="address" value="<?= $walker->address ?>" placeholder="{{ trans('customize.address')}}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.state') }}
                                </label>
                                <input class="form-control" type="text" name="state" value="<?= $walker->state ?>" placeholder="{{ trans('customize.state') }}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.city') }}
                                </label>
                                <input class="form-control" type="text" name="city" value="<?= $walker->city ?>" placeholder="{{ trans('customize.city') }}" >
                            </div>
                            <div class="form-group">
                                <?php
                                $countryCodes=DB::table('country_code')
                                        ->get();

                                $walkerTypes=DB::table('walker_type')
                                        ->get();

                                ?>
                                <label>Country</label>
                                <?php $country =  $walker->country?>
                                <select class="form-control" id="country" name="country">
                                    <option value="">{{ trans('customize.country') }}</option>
                                    <?php foreach ($countryCodes as $key=>$countryName): ?>
                                    <option value="<?php echo $countryName->name; ?>" <?php
                                            if (isset($country) && $walker->country == $countryName->name) {
                                                echo 'selected="selected"';
                                            }
                                            ?>><?php echo $countryName->name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <!--<input class="form-control" type="text" name="country" value="<?//= $walker->country ?>" placeholder="Country" >-->
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.zip_Code') }}</label>
                                <input class="form-control" type="text" name="zipcode" value="<?= $walker->zipcode ?>" placeholder="{{ trans('customize.zip_Code') }}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.phone') }}
                                </label>
                                <input class="form-control" type="text" name="phone" value="<?= $walker->phone ?>" placeholder="{{trans('customize.phone') }} " readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>
                                <h3>{{ trans('customize.vehicle'), ' ' ,trans('customize.documents') }}
                                </h3>
                            </label>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label>{{ trans('customize.car'), ' ' ,trans('customize.number')  }}
                                </label>
                                <input class="form-control" type="text" name="car_number" value="<?= $walker->car_number ?>" placeholder="{{ trans('customize.car'), ' ' ,trans('customize.number')  }}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.car'), ' ' ,trans('customize.model')  }}
                                </label>
                                <input class="form-control" type="text" name="car_model" value="<?= $walker->car_model ?>" placeholder="{{ trans('customize.car'), ' ' ,trans('customize.model')  }}" >
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.service'), ' ', trans('customize.type') }} </label>
                                <?php $type =  $walker->type?>
                                <select class="form-control" id="type" name="type">
                                    <option value="">{{ trans('customize.type') }}</option>
                                    <?php foreach ($walkerTypes as $key=>$Walker_type): ?>
                                    <option value="<?php echo $Walker_type->id; ?>" <?php
                                            if (isset($type) && $walker->type == $Walker_type->id) {
                                            echo 'selected="selected"';
                                            }
                                            ?>><?php echo $Walker_type->name ?></option>
                                    <?php endforeach; ?>
                                </select>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>
                                <h3>{{ trans('customize.status') }}
                                </h3>
                            </label>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label>{{ trans('customize.is_currently_providing') }} :
                                </label>
                                <?php
                                $walk = DB::table('walk')
                                ->select('id')
                                ->where('walk.is_started', 1)
                                ->where('walk.is_completed', 0)
                                ->where('walker_id', $walker->id);
                                $count = $walk->count();
                                if ($count > 0) {
                                echo "Yes";
                                } else {
                                echo "No";
                                }
                                ?>
                            </div>
                            <div class="form-group">
                                <label>{{ trans('customize.is_provider_active') }} :
                                </label>
                                <?php
                                $walk = DB::table('walker')
                                ->select('id')
                                ->where('walker.is_active', 1)
                                ->where('walker.id', $walker->id);
                                $count = $walk->count();
                                if ($count > 0) {
                                echo "Yes";
                                } else {
                                echo "No";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>
                                <h3>{{ trans('customize.identity')}}
                                </h3>
                            </label>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>{{ trans('customize.license') }}</label>
                                        <?php // echo $license_img; ?>
                                        <input type="file"  class="form-control" style="overflow:hidden;" value="<?= $license_img ?>" id="license_img" name="license_img"  >
                                    </div>
                                    <div class="col-md-6">
                                        <label>{{ trans('customize.expiry'),' ',trans('customize.date') }}</label>
                                        <input type="text"  class="form-control" style="overflow:hidden;"   id="license_expiry_date" name="license_expiry_date" value="<?= empty($license_expiry_date) ? "" : date("m/d/Y", strtotime($license_expiry_date));?>" placeholder="{{trans('customize.license'),' ',trans('customize.expiry'),' ',trans('customize.date') }}">
                                    </div>
                                </div>
                                <br>
                                <?php if(!empty($license_img)){ ?> <img src="<?= $license_img; ?>" height="50" width="50"><?php } ?>
                                <p class="help-block">{{ trans('customize.upload_image_format') }}
                                </p>
                            </div>
                            <!--</div>-->
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                    <label>{{ trans('customize.certificate') }}</label>
                                        <input type="file"  class="form-control" style="overflow:hidden;"   id="certificate_img" name="certificate_img">
                                    </div>
                                    <div class="col-md-6">
                                        <label>{{ trans('customize.expiry'),' ',trans('customize.date') }}</label>
                                        <input type="text"  class="form-control" style="overflow:hidden;"   id="certificate_expiry_date" name="certificate_expiry_date" value="<?= empty($certificate_expiry_date) ? "" : date("m/d/Y", strtotime($certificate_expiry_date)); ?>" placeholder="{{trans('customize.certificate'),' ',trans('customize.expiry'),' ',trans('customize.date') }}">
                                    </div>
                                </div>
                                <br>
                                <?php if(!empty($certificate_img)){ ?><img src="<?= $certificate_img; ?>" height="50" width="50"><?php } ?>
                                <p class="help-block">{{ trans('customize.upload_image_format') }}
                                </p>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>{{ trans('customize.insurance') }}</label>
                                        <input type="file"  class="form-control" style="overflow:hidden;"   id="insurance_img" name="insurance_img"  >
                                    </div>
                                    <div class="col-md-6">
                                        <label>{{ trans('customize.expiry'),' ',trans('customize.date') }}
                                        </label>
                                        <input type="text"  class="form-control" style="overflow:hidden;"   id="insurance_expiry_date" name="insurance_expiry_date" value="<?= empty($insurance_expiry_date) ? "" : date("m/d/Y", strtotime($insurance_expiry_date));?>" placeholder="{{trans('customize.insurance'),' ',trans('customize.expiry'),' ',trans('customize.date') }}">
                                    </div>
                                </div>
                                <br>
                               <?php if(!empty($insurance_img)){ ?> <img src="<?= $insurance_img; ?>" height="50" width="50"><?php } ?>
                                <br>
                                <p class="help-block">{{ trans('customize.upload_image_format') }}
                                </p>
                            </div>
                            <div class="form-group">
                                <div class="row">

                                    <div class="col-md-6">
                                        <label>{{ trans('customize.inspection') }}</label>
                                        <input type="file"  class="form-control" style="overflow:hidden;"   id="inspection_img" name="inspection_img"  >
                                        <br>
                                    </div>
                                    <div class="col-md-6">
                                        <label>{{ trans('customize.expiry'),' ',trans('customize.date') }}
                                        </label>
                                        <input type="text"  class="form-control" style="overflow:hidden;"   id="inspection_expiry_date" name="inspection_expiry_date" value="<?= empty($inspection_expiry_date) ? "" : date("m/d/Y", strtotime($inspection_expiry_date));?>" placeholder="{{trans('customize.inspection'),' ',trans('customize.expiry'),' ',trans('customize.date') }}">
                                    </div>
                                </div>
                                <?php if(!empty($inspection_img)){ ?> <img src="<?= $inspection_img; ?>" height="50" width="50"><?php } ?>
                                <p class="help-block">{{ trans('customize.upload_image_format') }}
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
                <!--</div>-->

                <div class="box-footer">
                    <button type="submit"  class="btn btn-primary btn-flat btn-block">{{ trans('update'),' ',trans('change'),'s' }}
                    </button>
                </div>
            </div>
        </form>
    </div>
    <?php if ($success == 1) { ?>
    <script type="text/javascript">
        alert('Walker Profile Updated Successfully');
    </script>
    <?php } ?>
    <?php if ($success == 2) { ?>
    <script type="text/javascript">
        alert('Sorry Something went Wrong');
    </script>
    <?php } ?>
    <script type="text/javascript">
        $(function () {
                    $("#license_expiry_date").datepicker({
                                defaultDate: "",
                                changeMonth: true,
                                numberOfMonths: 1,
                            }
                    );
                    $("#certificate_expiry_date").datepicker({
                                defaultDate: "",
                                changeMonth: true,
                                numberOfMonths: 1,
                            }
                    );
                    $("#insurance_expiry_date").datepicker({
                                defaultDate: "",
                                changeMonth: true,
                                numberOfMonths: 1,
                            }
                    );
                    $("#inspection_expiry_date").datepicker({
                                defaultDate: "",
                                changeMonth: true,
                                numberOfMonths: 1,
                            }
                    );
                }
        );
        $(document).ready(function () {
            $("#license_img").change(function(){
                var lic_img=$("#license_img").val();
                lic_req=((lic_img.length)>0) ? true : false;
                if(lic_req == true){
                    $("#license_expiry_date").prop('required',true)
                }
                else{
                    $('#license_expiry_date').removeAttr('required');
                }

            });
            $("#certificate_img").change(function(){
                var cer_img=$("#certificate_img").val();
                cer_req=((cer_img.length)>0) ? true : false;
                if(cer_req == true){
                    $("#certificate_expiry_date").prop('required',true)
                }
                else{
                    $('#certificate_expiry_date').removeAttr('required');
                }

            });

            $("#insurance_img").change(function(){
                var insur_img=$("#insurance_img").val();
                var insur_req=((insur_img.length)>0) ? true : false;
                if(insur_req == true){
                    $("#insurance_expiry_date").prop('required',true)
                }
                else{
                    $('#insurance_expiry_date').removeAttr('required');
                }

            });
            $("#inspection_img").change(function(){
                var insp_img=$("#inspection_img").val();
                var insp_req=((insp_img.length)>0) ? true : false;
                if(insp_req == true){
                    $("#inspection_expiry_date").prop('required',true)
                }
                else{
                    $('#inspection_expiry_date').removeAttr('required');
                }

            });




            $('#main_form').validate({ // initialize the plugin
                rules: {
                    first_name: "required",
                    last_name:"required",
                    email:"required",
                    bio:"required",
                    address:"required",
                    country:"required",
                    state:"required",
                    city:"required",
                    zipcode:"required",
                    country_code:"required",
                    phone:"required",
                    car_number:"required",
                    car_model:"required",
                    type:"required",
                    password:"required",
                    confirm_password: {
                        equalTo: "#password"
                    },
                   // license_img:"required",
                   // license_expiry_date:"required",
                    field2: {
                        required: true,
                        minlength: 5
                    }
                }
            });

        });

    </script>
    <style>
        .panel-default > .panel-heading {
            color: #333;
            background-color: #ec7171 !important;
            /*#f5f5f5*/
            border-color: #ddd;
        }
    </style>
@stop
