@extends('layout')

@section('content')

    {{-- <script src="https://bitbucket.org/pellepim/jstimezonedetect/downloads/jstz-1.0.4.min.js"></script>
     <script src="http://momentjs.com/downloads/moment.min.js"></script>
     <script src="http://momentjs.com/downloads/moment-timezone-with-data.min.js"></script>--}}

    <!-- <div class="box box-danger">
        <form method="get" action="{{ URL::Route('/admin/searchrev') }}">
            <div class="box-header">
                <h3 class="box-title">Filter</h3>
            </div>
            <div class="box-body row">
                <div class="col-md-6 col-sm-12">
                    <select id="searchdrop" class="form-control" name="type">
                        <option value="owner" id="owner">{{ trans('customize.User');}} Name</option>
                        <option value="walker" id="walker">{{ trans('customize.Provider');}}</option>
                    </select>
                    <br>
                </div>
                <div class="col-md-6 col-sm-12">
                    <input class="form-control" type="text" name="valu" value="<?php if (Session::has('valu')) {
        echo Session::get('valu');
    } ?>" id="insearch" placeholder="keyword"/>
                    <br>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" id="btnsearch" class="btn btn-flat btn-block btn-success serach_blad">Search
                </button>
            </div>
        </form>
    </div> -->

    <div class="box box-info tbl-box">
        <div class="col-md-12 col-sm-12">
            <div class="col-md-6 col-sm-6">
                &nbsp;
            </div>
            {{--<div class="col-md-6 col-sm-6">
                <a id="currently" href="{{ URL::Route('EditCategories', 0) }}"><button class="col-md-12 col-sm-12 btn btn-flat btn-block  btn-warning"  type="button">Add New Category</button></a><br/>
                <br><br>
            </div>--}}
        </div>
        <table class="table table-bordered">
            <tbody>
            <tr>
                <th>{{ trans('customize.s_no') }}</th>
                <th>{{ trans('customize.zone_name') }}</th>
                <th><?php echo Lang::get('customize.action'); ?></th>
            </tr>
            <?php $i = 1; ?>
            <?php
            $zoneName = array();
            foreach ($zoneTypeRecords as $key => $zonetype) : ?>
            <tr>
                <?php if(!in_array($zonetype->zone_name, $zoneName)) : ?>
                <td><?php echo $i; ?> </td>
                <td><?php echo $zonetype->zone_name; ?> </td>
            <!--<td><?php echo date('Y-m-d H:m:s', strtotime($zonetype->created_at)); ?></td>-->

                <td>
                    <div class="dropdown">
                        <button class="btn btn-flat btn-info dropdown-toggle" type="button" id="dropdownMenu1"
                                data-toggle="dropdown">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                            <li role="presentation"><a role="menuitem" tabindex="-1" id="edit"
                                                       href="{{ URL::Route('EditViewZoneDivision', $zonetype->id) }}">Edit
                                    Zone Division</a>
                            </li>
                            <li role="presentation"><a role="menuitem" tabindex="-1" id="del_cat" class="confirmation"
                                                       href="{{ URL::Route('DeleteZoneDivision', $zonetype->id) }}">Delete</a>
                            </li>
                        </ul>
                    </div>
                </td>
                <?php array_push($zoneName, $zonetype->zone_name);
                $i++; ?>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div align="left" id="paglink"></div>
    </div><!-- /.tab-pane -->




    <script type="text/javascript">
        $('.confirmation').on('click', function () {
            return confirm('Are you sure you want to delete?');
        });
    </script>

@stop