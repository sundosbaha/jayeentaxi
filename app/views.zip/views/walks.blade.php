@extends('layout')

@section('content')

<script src="https://bitbucket.org/pellepim/jstimezonedetect/downloads/jstz-1.0.4.min.js"></script>
<script src="http://momentjs.com/downloads/moment.min.js"></script>
<script src="http://momentjs.com/downloads/moment-timezone-with-data.min.js"></script>

<div class="col-md-6 col-sm-12">

    <div class="box box-danger">

        <form method="get" action="{{ URL::Route('/admin/sortreq') }}">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.sort') }}</h3>
            </div>
            <div class="box-body row">

                <div class="col-md-6 col-sm-12">

                    <select class="form-control" id="sortdrop" name="type">
                        <option value="reqid" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'reqid') {
                            echo 'selected="selected"';
                        }
                        ?>  id="reqid">{{ trans('customize.Request'),' ', strtoupper(trans('customize.id')) }} </option>
                        <option value="owner" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'owner') {
                            echo 'selected="selected"';
                        }
                        ?>  id="owner">{{ trans('customize.User'),' ',trans('customize.name');}}</option>
                        <option value="walker" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'walker') {
                            echo 'selected="selected"';
                        }
                        ?>  id="walker">{{ trans('customize.Provider');}}</option>
                        <option value="payment" <?php
                        if (isset($_GET['type']) && $_GET['type'] == 'payment') {
                            echo 'selected="selected"';
                        }
                        ?>  id="payment">{{trans('customize.payment'),' ',trans('customize.mode')}}</option>
                    </select>

                    <br>
                </div>
                <div class="col-md-6 col-sm-12">
                    <select class="form-control" id="sortdroporder" name="valu">
                        <option value="asc" <?php
                        if (isset($_GET['type']) && $_GET['valu'] == 'asc') {
                            echo 'selected="selected"';
                        }
                        ?>  id="asc">{{trans('customize.ascending')}}</option>
                        <option value="desc" <?php
                        if (isset($_GET['type']) && $_GET['valu'] == 'desc') {
                            echo 'selected="selected"';
                        }
                        ?>  id="desc">{{trans('customize.descending')}}</option>
                    </select>

                    <br>
                </div>

            </div>

            <div class="box-footer">

                <button type="submit" id="btnsort" class="btn btn-flat btn-block btn-success">{{ trans('customize.sort') }}</button>
                <button type="submit" id="btnsort" name="submit" class="btn btn-flat btn-block btn-success" value="Download_Report">{{ trans('customize.download'),' ',trans('customize.report')  }}</button>
            </div>
        </form>

    </div>
</div>


<div class="col-md-6 col-sm-12">

    <div class="box box-danger">

        <form method="get" action="{{ URL::Route('/admin/searchreq') }}">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.filter') }}</h3>
            </div>
            <div class="box-body row">

                <div class="col-md-6 col-sm-12">

                    <select class="form-control" id="searchdrop" name="filter_type">
                        <option value="reqid" id="reqid" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'reqid') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.Request'),' ',strtoupper(trans('customize.id'))  }}</option>
                        <option value="booking_id" id="booking_id" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'booking_id') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.booking'),' ',strtoupper(trans('customize.id'))  }}
                        </option>
                        <option value="owner" id="owner" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'owner') {
                                    echo 'selected="selected"';
                                }
                                ?> >{{ trans('customize.User'), ' ' ,trans('customize.name')}} </option>
                        <option value="walker" id="walker" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'walker') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{ trans('customize.Provider');}}</option>
                        <option value="payment" id="payment" <?php
                                if (isset($_GET['filter_type']) && $_GET['filter_type'] == 'payment') {
                                    echo 'selected="selected"';
                                }
                                ?>>{{trans('customize.payment'),' ',trans('customize.mode')}}</option>
                    </select>

                    <br>
                </div>
                <div class="col-md-6 col-sm-12">

                    <input class="form-control" type="text" name="filter_valu" value="<?php echo (!empty($_GET['filter_valu']) ? $_GET['filter_valu'] : '');
                    ?>" id="insearch" placeholder="{{ trans('customize.keyword'); }}"/>
                    <br>
                </div>

            </div>

            <div class="box-footer">
                <button type="submit" id="btnsearch" class="btn btn-flat btn-block btn-success">{{ trans('customize.search')}}</button>
                <button type="submit" id="btnsearch" name="submit" class="btn btn-flat btn-block btn-success" value="Download_Report">{{ trans('customize.download'),' ', trans('customize.report') }}</button>
            </div>
        </form>

    </div>
</div>



<div class="box box-info tbl-box">
    <div align="left" id="paglink"><?php echo $walks->appends(array('type' => Session::get('type'), 'valu' => Session::get('valu')))->links(); ?></div>
    <table class="table table-bordered">
        <tbody>
            <tr>
                <th>{{ trans('customize.Request'),' ', strtoupper(trans('customize.id'))}}</th>
                <th>{{ trans('customize.booking'),' ', strtoupper(trans('customize.id'))}}</th>
                <th>{{ trans('customize.User'),' ', trans('customize.name');}}</th>
                <th>{{ trans('customize.Provider');}}</th>
                <th>{{ trans('customize.date'),'/', trans('customize.time')}}</th>
                <th>{{ trans('customize.status')}}</th>
                <th>{{ trans('customize.amount')}}</th>
                <th>{{ trans('customize.payment'),' ', trans('customize.mode')}}</th>
                <th>{{ trans('customize.payment'),' ', trans('customize.status')}}</th>
                <th>{{ trans('customize.action')}}</th>
            </tr>
            <?php $i = 0; ?>

            <?php  if(count($walks) > 0) :
            foreach ($walks as $walk) { ?>
                <tr>
                    <td><?= $walk->id ?></td>
                    <td><?= (!empty($walk->booking_id) ? $walk->booking_id : '--') ?></td>
                    <td><?php echo $walk->owner_first_name . " " . $walk->owner_last_name; ?> </td>
                    <td>
                        <?php
                        if ($walk->confirmed_walker) {
                            echo $walk->walker_first_name . " " . $walk->walker_last_name;
                        } else {
                            echo trans('customize.un_assigned');
                        }
                        ?>
                    </td>
                   <!-- <td id= 'time<?php //echo $i; ?>' >
                        <script>
    var timezone = jstz.determine();
    // console.log(timezone.name());
    var timevar = moment.utc("<?php //echo $walk->date; ?>");
    timevar.toDate();
    timevar.tz(timezone.name());
    // console.log(timevar);
    document.getElementById("time<?php //echo $i; ?>").innerHTML = timevar;
    <?php //$i++; ?>
                        </script>
                    </td>-->
                    <?php
                    $default_timezone = Config::get('app.timezone');
                    $user_timezone = Config::get('app.usertimezone');
                    $date_time = get_user_time($default_timezone, $user_timezone, $walk->date);
                    ?>
                    <td> <?php echo date('Y-m-d/H:m:s', strtotime($date_time)); ?> </td>

                    <td>
                        <?php
                        if ($walk->is_cancelled == 1) {
                            echo "<span class='badge bg-red'>". trans('customize.cancelled')."</span>";
                        } elseif ($walk->is_completed == 1) {
                            echo "<span class='badge bg-green'>". trans('customize.completed')."</span>";
                        } elseif ($walk->is_started == 1) {
                            echo "<span class='badge bg-yellow'>". trans('customize.start')."ed"."</span>";
                        } elseif ($walk->is_walker_arrived == 1) {
                            echo "<span class='badge bg-yellow'>".trans('customize.walker').' '.trans('customize.arrived')."</span>";
                        } elseif ($walk->is_walker_started == 1) {
                            echo "<span class='badge bg-yellow'>".trans('customize.walker').' '.trans('customize.start')."ed"."</span>";
                        } else {
                            echo "<span class='badge bg-light-blue'>".trans('customize.yet_to_start')."</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <?php echo sprintf2($walk->total, 2); ?>
                    </td>
                    <td>
                        <?php
                        if ($walk->payment_mode == 0) {
                            echo "<span class='badge bg-orange'>".trans('customize.stored').' '.trans('customize.card')."s"."</span>";
                        } elseif ($walk->payment_mode == 1) {
                            echo "<span class='badge bg-blue'>".trans('customize.pay_by_cash')."</span>";
                        } elseif ($walk->payment_mode == 2) {
                            echo "<span class='badge bg-purple'>".trans('customize.pay_pal')."</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($walk->is_paid == 1) {
                            echo "<span class='badge bg-green'>".trans('customize.completed')."</span>";
                        } elseif ($walk->is_paid == 0 && $walk->is_completed == 1) {
                            echo "<span class='badge bg-red'>".trans('customize.pending')."</span>";
                        } else {
                            echo "<span class='badge bg-yellow'>".trans('customize.request_not_completed')."</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-flat btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                                {{ trans('customize.action')}}
                                <span class="caret"></span>
                            </button>
                            <?php /* echo Config::get('app.generic_keywords.Currency'); */ ?>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                <li role="presentation"><a role="menuitem" id="map" tabindex="-1" href="{{ URL::Route('AdminRequestsMap', $walk->id) }}">{{ trans('customize.view_map') }}</a></li>
                                @if($setting->value==1 && $walk->is_completed==1 && (Config::get('app.generic_keywords.Currency')=='$' || Config::get('app.default_payment') != 'stripe'))
                                <li role="presentation"><a role="menuitem" id="map" tabindex="-1" href="{{ URL::Route('AdminPayProvider', $walk->id) }}">{{ trans('customize.transfer'),' ',trans('customize.amount') }}</a></li>
                                @endif
                                @if($walk->is_paid==0 && $walk->is_completed==1 && $walk->payment_mode!=1 && $walk->total!=0)
                                <li role="presentation"><a role="menuitem" id="map" tabindex="-1" href="{{ URL::Route('AdminChargeUser', $walk->id) }}"> {{trans('customize.change'),' ', trans('customize.User');}}</a></li>
                                @endif
                                <!--
                                <li role="presentation" class="divider"></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo web_url(); ?>/admin/walk/delete/<?= $walk->id; ?>">Delete Walk</a></li>
                                -->
                            </ul>
                        </div>  

                    </td>
                </tr>
            <?php } else :?>
            <tr>
                <td colspan="10"><?php echo trans('customize.no_record_found'); ?></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div align="left" id="paglink"><?php echo $walks->appends(array('type' => Session::get('type'), 'valu' => Session::get('valu')))->links(); ?></div>




</div>

<!--
  <script>
  $(function() {
    $( "#start-date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
      onClose: function( selectedDate ) {
        $( "#end-date" ).datepicker( "option", "minDate", selectedDate );
      }
    });
    $( "#end-date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
      onClose: function( selectedDate ) {
        $( "#start-date" ).datepicker( "option", "maxDate", selectedDate );
      }
    });
  });
  </script>
-->

<script type="text/javascript">
</script>

<style type="text/css">

    #btnsort {
        width: 49% !important;
        left: 0% !important;
    }
    #btnsearch, .btn-warning {
        width: 49% !important;
        left: 0% !important;
    }

</style>
@stop