<?php print_R($detail); ?>
