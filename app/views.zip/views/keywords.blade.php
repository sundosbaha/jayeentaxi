@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-6 col-sm-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.Customize'),' ',trans('customize.application'),' ',trans('customize.backend'),' ',trans('customize.keyword'),'s' }}</h3>
            </div><!-- /.box-header -->
            <!-- form start -->
            <form method="post" action="{{ URL::Route('AdminKeywordsSave') }}"  enctype="multipart/form-data">
                <div class="box-body">
                    <div class="form-group">
                        <label>  {{ trans('customize.providers') }} </label>
                        <input class="form-control" type="text" name="key_provider" value="{{ Config::get('app.generic_keywords.Provider') }}" placeholder="{{ trans('customize.value'),' ',trans('customize.for'),' ',trans('customize.provider'),' ',trans('customize.keyword')  }}">
                    </div>
                    <div class="form-group">
                        <label> {{ trans('customize.User') }} </label>
                        <input class="form-control" type="text" name="key_user" value="{{ Config::get('app.generic_keywords.User') }}" placeholder="{{ trans('customize.value'),' ',trans('customize.for'),' ',trans('customize.User'),' ',trans('customize.keyword')  }}">
                    </div>
                    <div class="form-group">
                        <label> {{ trans('customize.Taxi') }} </label>
                        <input class="form-control" type="text" name="key_taxi" value="{{ Config::get('app.generic_keywords.Services') }}" placeholder="{{ trans('customize.value'),' ',trans('customize.for'),' ',trans('customize.Taxi'),' ',trans('customize.keyword')  }}">
                    </div>
                    <div class="form-group">
                        <label>  {{ trans('customize.Trip') }} </label>
                        <input class="form-control" type="text" name="key_trip" value="{{ Config::get('app.generic_keywords.Trip') }}" placeholder="{{ trans('customize.value'),' ',trans('customize.for'),' ',trans('customize.Trip'),' ',trans('customize.keyword')  }}">
                    </div>
                    <div class="form-group">
                        <label>  {{ trans('customize.currency') }} </label>
                        <select name="key_currency" id="currencies" class="form-control">
                            <option value="AUD" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'AUD') {
                                echo "selected";
                            }
                            ?>>Australia Dollar</option> 
                            <option value="CAD" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'CAD') {
                                echo "selected";
                            }
                            ?>>Canada Dollar</option>
                            <option value="CHF" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'CHF') {
                                echo "selected";
                            }
                            ?>>Switzerland Franc</option>
                            <option value="DKK" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'DKK') {
                                echo "selected";
                            }
                            ?>>Denmark Krone</option>
                            <option value="EUR" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'EUR') {
                                echo "selected";
                            }
                            ?>>Euro Member Countries</option>
                            <option value="GBP" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'GBP') {
                                echo "selected";
                            }
                            ?>>United Kingdom Pound</option> 
                            <option value="HKD" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'HKD') {
                                echo "selected";
                            }
                            ?>>Hong Kong Dollar</option>
                            <option value="JPY" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'JPY') {
                                echo "selected";
                            }
                            ?>>Japan Yen</option>
                            <option value="MXN" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'MXN') {
                                echo "selected";
                            }
                            ?>>Mexico Peso</option>
                            <option value="NZD" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'NZD') {
                                echo "selected";
                            }
                            ?>>New Zealand Dollar</option>
                            <option value="PHP" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'PHP') {
                                echo "selected";
                            }
                            ?>>Philippines Peso</option>
                            <option value="SEK" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'SEK') {
                                echo "selected";
                            }
                            ?>>Sweden Krona</option>
                            <option value="SGD" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'SGD') {
                                echo "selected";
                            }
                            ?>>Singapore Dollar</option>
                            <option value="SPL" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'SPL') {
                                echo "selected";
                            }
                            ?>>Seborga Luigino</option>
                            <option value="THB" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'THB') {
                                echo "selected";
                            }
                            ?>>Thailand Baht</option>
                            <option value="$" <?php
                            if (Config::get('app.generic_keywords.Currency') == '$') {
                                echo "selected";
                            }
                            ?>>United States Dollar</option>
                            <option value="ZAR" <?php
                            if (Config::get('app.generic_keywords.Currency') == 'ZAR') {
                                echo "selected";
                            }
                            ?>>South Africa Rand</option>

                        </select>
                    </div>
                    <?php
                    if (isset($keywords)) {
                        foreach ($keywords as $keyword) {
                            if ($keyword->id != 5) {
                                /* if ($keyword->id < 5) {
                                  ?>

                                  <div class="form-group">
                                  <label>
                                  <?php
                                  echo $keyword->id . ". " . ucfirst($keyword->alias);
                                  ?>
                                  </label>
                                  <input class="form-control" type="text" name="{{$keyword->id}}" value="{{$keyword->keyword}}" />
                                  </div>
                                  <?php
                                  } */
                            } else {
                                ?>
                                <!--<div class="form-group">
                                    <label>
                                <?php
                                echo $keyword->id . ". " . ucfirst($keyword->alias);
                                ?>
                                    </label>
                                    <select name="{{$keyword->id}}" id="currencies" class="form-control">
                                        <option value="AUD" <?php
                                if ($keyword->keyword == 'AUD') {
                                    echo "selected";
                                }
                                ?>>Australia Dollar</option> 
                                        <option value="CAD" <?php
                                if ($keyword->keyword == 'CAD') {
                                    echo "selected";
                                }
                                ?>>Canada Dollar</option>
                                        <option value="CHF" <?php
                                if ($keyword->keyword == 'CHF') {
                                    echo "selected";
                                }
                                ?>>Switzerland Franc</option>
                                        <option value="DKK" <?php
                                if ($keyword->keyword == 'DKK') {
                                    echo "selected";
                                }
                                ?>>Denmark Krone</option>
                                        <option value="EUR" <?php
                                if ($keyword->keyword == 'EUR') {
                                    echo "selected";
                                }
                                ?>>Euro Member Countries</option>
                                        <option value="GBP" <?php
                                if ($keyword->keyword == 'GBP') {
                                    echo "selected";
                                }
                                ?>>United Kingdom Pound</option> 
                                        <option value="HKD" <?php
                                if ($keyword->keyword == 'HKD') {
                                    echo "selected";
                                }
                                ?>>Hong Kong Dollar</option>
                                        <option value="JPY" <?php
                                if ($keyword->keyword == 'JPY') {
                                    echo "selected";
                                }
                                ?>>Japan Yen</option>
                                        <option value="MXN" <?php
                                if ($keyword->keyword == 'MXN') {
                                    echo "selected";
                                }
                                ?>>Mexico Peso</option>
                                        <option value="NZD" <?php
                                if ($keyword->keyword == 'NZD') {
                                    echo "selected";
                                }
                                ?>>New Zealand Dollar</option>
                                        <option value="PHP" <?php
                                if ($keyword->keyword == 'PHP') {
                                    echo "selected";
                                }
                                ?>>Philippines Peso</option>
                                        <option value="SEK" <?php
                                if ($keyword->keyword == 'SEK') {
                                    echo "selected";
                                }
                                ?>>Sweden Krona</option>
                                        <option value="SGD" <?php
                                if ($keyword->keyword == 'SGD') {
                                    echo "selected";
                                }
                                ?>>Singapore Dollar</option>
                                        <option value="SPL" <?php
                                if ($keyword->keyword == 'SPL') {
                                    echo "selected";
                                }
                                ?>>Seborga Luigino</option>
                                        <option value="THB" <?php
                                if ($keyword->keyword == 'THB') {
                                    echo "selected";
                                }
                                ?>>Thailand Baht</option>
                                        <option value="$" <?php
                                if ($keyword->keyword == '$') {
                                    echo "selected";
                                }
                                ?>>United States Dollar</option>
                                        <option value="ZAR" <?php
                                if ($keyword->keyword == 'ZAR') {
                                    echo "selected";
                                }
                                ?>>South Africa Rand</option>

                                    </select>
                                </div>-->
                                <?php
                            }
                        }
                    }
                    ?>
                    <div class="form-group">
                        <label>{{ trans('customize.total'),' ',trans('customize.Trip'),'s',' ',trans('customize.icon') }}</label>

                        <select class="form-control" style="font-family: 'FontAwesome', Helvetica;" name="total_trip">
                            <?php foreach ($icons as $key) { ?>
                                <option value="<?php echo $key->id; ?>" 
                                <?php
                                /* $icon = Keywords::where('keyword', 'total_trip')->first(); */
                                if (Config::get('app.generic_keywords.total_trip') == $key->id) {
                                    echo "selected";
                                }
                                ?> >
                                            <?php echo "  " . $key->icon_code . "  " . $key->icon_name; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{{trans('customize.completed'),' ',trans('customize.Trip'),'s',' ',trans('customize.icon') }}</label>

                        <select class="form-control" style="font-family: 'FontAwesome', Helvetica;" name="completed_trip">
                            <?php foreach ($icons as $key) { ?>
                                <option value="<?php echo $key->id; ?>" 
                                <?php
                                /* $icon = Keywords::where('keyword', 'completed_trip')->first(); */
                                if (Config::get('app.generic_keywords.completed_trip') == $key->id) {
                                    echo "selected";
                                }
                                ?> >
                                            <?php echo "  " . $key->icon_code . "  " . $key->icon_name; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.cancelled'),' ',trans('customize.Trip'),' ',trans('customize.icon') }}</label>

                        <select class="form-control" style="font-family: 'FontAwesome', Helvetica;" name="cancelled_trip">
                            <?php foreach ($icons as $key) { ?>
                                <option value="<?php echo $key->id; ?>" 
                                <?php
                                /* $icon = Keywords::where('keyword', 'cancelled_trip')->first(); */
                                if (Config::get('app.generic_keywords.cancelled_trip') == $key->id) {
                                    echo "selected";
                                }
                                ?> >
                                            <?php echo "  " . $key->icon_code . "  " . $key->icon_name; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.total'),' ',trans('customize.payment'),' ',trans('customize.icon') }}</label>

                        <select class="form-control" style="font-family: 'FontAwesome', Helvetica;" name="total_payment">
                            <?php foreach ($icons as $key) { ?>
                                <option value="<?php echo $key->id; ?>" 
                                <?php
                                /* $icon = Keywords::where('keyword', 'total_payment')->first(); */
                                if (Config::get('app.generic_keywords.total_payment') == $key->id) {
                                    echo "selected";
                                }
                                ?> >
                                            <?php echo "  " . $key->icon_code . "  " . $key->icon_name; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.credit'),' ',trans('customize.payment'),' ',trans('customize.icon') }}</label>

                        <select class="form-control" style="font-family: 'FontAwesome', Helvetica;" name="credit_payment">
                            <?php foreach ($icons as $key) { ?>
                                <option value="<?php echo $key->id; ?>" 
                                <?php
                                /* $icon = Keywords::where('keyword', 'credit_payment')->first(); */
                                if (Config::get('app.generic_keywords.credit_payment') == $key->id) {
                                    echo "selected";
                                }
                                ?> >
                                            <?php echo "  " . $key->icon_code . "  " . $key->icon_name; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.card'),' ',trans('customize.payment'),' ',trans('customize.icon') }}</label>

                        <select class="form-control" style="font-family: 'FontAwesome', Helvetica;" name="card_payment">
                            <?php foreach ($icons as $key) { ?>
                                <option value="<?php echo $key->id; ?>" 
                                <?php
                                /* $icon = Keywords::where('keyword', 'card_payment')->first(); */
                                if (Config::get('app.generic_keywords.card_payment') == $key->id) {
                                    echo "selected";
                                }
                                ?> >
                                            <?php echo "  " . $key->icon_code . "  " . $key->icon_name; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <!--<div class="form-group">
                        <label> Referral Prefix </label>
                        <input class="form-control" type="text" name="key_ref_pre" value="{{ Config::get('app.referral_prefix') }}" placeholder="Fixed Prefix for Referral Code">
                    </div>-->
                    <input class="form-control" type="hidden" name="key_ref_pre" value="{{ Config::get('app.referral_prefix') }}" placeholder="Fixed Prefix for Referral Code">

                </div>



                <div class="box-footer">
                    <button type="submit" class="btn btn-primary btn-flat btn-block">{{ trans('customize.update'),' ',trans('customize.change'),'s' }}</button>
                </div>
            </form>
        </div>

    </div>
    <div class="col-md-6 col-sm-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">{{ trans('customize.edit'),' ',trans('customize.application'),' ',trans('customize.ui'),' ',trans('customize.keyword'),'s' }}</h3>
            </div>
            <form role="form" method="POST" action="{{ URL::Route('AdminUIKeywordsSave') }}"  enctype="multipart/form-data">
                <div class="box-body">
                    <div class="form-group">
                        <label>{{ trans('customize.Dashboard') }}</label>
                        <input type="text" class="form-control" name="val_dashboard" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Dashboard') }}" value="{{$Uikeywords['keyDashboard']}}">
                    </div>
                    <div class="form-group">
                        <label >{{ trans('customize.map_view') }}</label>
                        <input type="text" class="form-control" name="val_map_view" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.map_view') }}" value="{{$Uikeywords['keyMap_View']}}">
                    </div>
                    <div class="form-group">
                        <label >{{ trans('customize.providers') }}</label>
                        <input type="text" class="form-control" name="val_provider" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.providers') }}" value="{{$Uikeywords['keyProvider']}}">
                    </div>
                    <div class="form-group">
                        <label >{{ trans('customize.User') }}</label>
                        <input type="text" class="form-control" name="val_user" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.User') }}" value="{{$Uikeywords['keyUser']}}">
                    </div>
                    <div class="form-group">
                        <label >{{ trans('customize.Taxi') }}</label>
                        <input type="text" class="form-control" name="val_taxi" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Taxi') }}" value="{{$Uikeywords['keyTaxi']}}">
                    </div>
                    <div class="form-group">
                        <label >{{ trans('customize.Trip') }}</label>
                        <input type="text" class="form-control" name="val_trip" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Trip') }}" value="{{$Uikeywords['keyTrip']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Walk') }}</label>
                        <input type="text" class="form-control" name="val_walk" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Walk') }}" value="{{$Uikeywords['keyWalk']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Request') }}</label>
                        <input type="text" class="form-control" name="val_request" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Request') }}" value="{{$Uikeywords['keyRequest']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.reviews') }}</label>
                        <input type="text" class="form-control" name="val_reviews" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.reviews') }}" value="{{$Uikeywords['keyReviews']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Information'),'s' }}</label>
                        <input type="text" class="form-control" name="val_information" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Information'),'s' }}" value="{{$Uikeywords['keyInformation']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Types') }}</label>
                        <input type="text" class="form-control" name="val_types" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Types') }}" value="{{$Uikeywords['keyTypes']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Documents') }}</label>
                        <input type="text" class="form-control" name="val_documents" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Documents') }}" value="{{$Uikeywords['keyDocuments']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.promo_codes') }}</label>
                        <input type="text" class="form-control" name="val_promo_codes" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.promo_codes') }}" value="{{$Uikeywords['keyPromo_Codes']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Customize')}}</label>
                        <input type="text" class="form-control" name="val_customize" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Customize') }}" value="{{$Uikeywords['keyCustomize']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.payment'),' ',trans('customize.details') }}</label>
                        <input type="text" class="form-control" name="val_payment_details" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.payment'),' ',trans('customize.details') }}" value="{{$Uikeywords['keyPayment_Details']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Settings') }}</label>
                        <input type="text" class="form-control" name="val_settings" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Settings') }}" value="{{$Uikeywords['keySettings']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.Admin') }}</label>
                        <input type="text" class="form-control" name="val_admin" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.Admin') }}" value="{{$Uikeywords['keyAdmin']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.admin_control') }}</label>
                        <input type="text" class="form-control" name="val_admin_control" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.admin_control') }}" value="{{$Uikeywords['keyAdmin_Control']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.previlege') }}</label>
                        <input type="text" class="form-control" name="val_previlege" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.previlege') }}" value="{{$Uikeywords['previlege']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.dispatchers') }}</label>
                        <input type="text" class="form-control" name="val_dispatcher" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.dispatchers') }}" value="{{$Uikeywords['dispatcher']}}">
                    </div>
                    <div class="form-group">
                        <label>{{ trans('customize.log_out') }}</label>
                        <input type="text" class="form-control" name="val_log_out" placeholder="{{ trans('customize.keyword'),' ',trans('customize.for'),' ',trans('customize.log_out') }}" value="{{$Uikeywords['keyLog_Out']}}">
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary btn-flat btn-block">{{ trans('customize.update'),' ',trans('customize.change'),'s' }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    function Checkfiles()
    {
        var fup = document.getElementById('logo');
        var fileName = fup.value;
        if (fileName != '')
        {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
            if (ext == "PNG" || ext == "png")
            {
                return true;
            }
            else
            {
                alert("Upload PNG Images only for Logo");
                return false;
            }
        }
        var fup = document.getElementById('icon');
        var fileName1 = fup.value;
        if (fileName1 != '')
        {
            var ext = fileName1.substring(fileName1.lastIndexOf('.') + 1);

            if (ext == "ICO" || ext == "ico")
            {
                return true;
            }
            else
            {
                alert("Upload Icon Images only for Favicon");
                return false;
            }
        }
    }
</script>
<?php if ($success == 1) { ?>
    <script type="text/javascript">
        alert('Settings Updated Successfully');
    </script>
<?php } ?>
<?php if ($success == 2) { ?>
    <script type="text/javascript">
        alert('Sorry Something went Wrong');
    </script>
<?php } ?>
<script>
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
    });
</script>
<script type="text/javascript">
    $("#currencies").change(function () {
        var currency_selected = $("#currencies option:selected").val();
        console.log(currency_selected);
        $.ajax({
            type: "POST",
            url: "{{route('adminCurrency')}}",
            data: {'currency_selected': currency_selected},
            success: function (data) {
                if (data.success == true) {
                    console.log(data.rate);
                } else {
                    console.log(data.error_message);
                }
            }
        });
    });
</script>
@stop