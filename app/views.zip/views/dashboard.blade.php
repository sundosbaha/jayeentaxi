@extends('layout')

@section('content')
<?php
if (!isset($_COOKIE['skipInstallation'])) {
    if (Session::has('notify')) {
        $message = '';
        $message1 = $message2 = $message3 = '';
        if ($install['mail_driver'] == '' && $install['email_address'] == '' && $install['email_name'] == '') {
            $message1 = 'Mail Configuration Missing During Installation';
        }
        if ($install['twillo_account_sid'] == '' && $install['twillo_auth_token'] == '' && $install['twillo_number'] == '') {
            $message2 = 'SMS Configuration Missing During Installation';
        }
        if (($install['default_payment'] == '' && $install['braintree_environment'] == '' && $install['braintree_merchant_id'] == '' && $install['braintree_public_key'] == '' && $install['braintree_private_key'] == '' && $install['braintree_cse'] == '') && ( $install['stripe_publishable_key'] == '')) {
            $message3 = 'Payment Configuration Missing During Installation';
        }
        if ($message1 != '' && $message2 != '' && $message3 != '') {
            $message = "SMS, Mail, Payment Configuration Missing";
        } else if ($message1 != '' && $message2 != '') {
            $message = "SMS, Mail Configuration Missing";
        } else if ($message1 != '' && $message3 != '') {
            $message = "Mail, Payment Configuration Missing";
        } else if ($message3 != '' && $message2 != '') {
            $message = "SMS, Payment Configuration Missing";
        } else if ($message1 != '' && $message3 == '' && $message2 == '') {
            $message = $message1;
        } else if ($message2 != '' && $message1 == '' && $message3 == '') {
            $message = $message2;
        } else if ($message3 != '' && $message1 == '' && $message2 == '') {
            $message = $message3;
        }

        if ($message != '') {
            ?>
            <div id="myModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">{{ trans('customize.installation'),' ',trans('customize.notification') }}</h4>
                        </div>
                        <div class="modal-body">
                            <p><?php echo $message; ?></p>
                        </div>
                        <div class="modal-footer">
                            <a href="{{ URL::Route('AdminSettingDontShow') }}"><button type="button" class="btn btn-default" >{{ trans('customize.dont_show_again'); }}</button></a>
                            <button type="button" class="btn btn-default" data-dismiss="modal">{{ trans('customize.close') }}</button>
                            <a href="{{ URL::Route('AdminSettingInstallation') }}"><button type="button" class="btn btn-primary">{{ trans('customize.change'),' ',trans('customize.now') }}</button></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
}
?>


<!--   summary start -->

<!--New dashboard code starts here-->
   <div class="row">


       <div class="panel panel-primary text-center no-boder bg-color-green">
           <div class="panel-body">
               <i class="fa fa-bar-chart-o fa-5x"></i>
               <h3>8,457</h3>
           </div>
           <div class="panel-footer back-footer-green">
               Daily Visits

           </div>
       </div>



       <div class="col-md-12 col-sm-12 col-xs-12 padding-right-30 padding-left-20">
             <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 padding-right-0 padding-left-0">
                 <div class="r4_counter wid-stats db_box">
                    <div class="stats-data">
                         <i class="fa material-icons icon-primary pull-left" aria-hidden="true"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.total_trip'));
                    echo $show->icon_code;
                    ?></i>
                        <div class="stats">
                                <h3><?= $completed_rides + $cancelled_rides ?></h3>
                                <span>{{trans('customize.total'),' ',trans('customize.trip')}}s </span>
                            </div>
                    </div>
                 </div>
             </div>
             <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 padding-right-0 padding-left-0">
                 <div class="r4_counter wid-stats db_box">
                    <div class="stats-data">
                         <i class="fa material-icons icon-primary pull-left" aria-hidden="true"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.completed_trip'));
                    echo $show->icon_code;
                    ?></i>
                        <div class="stats">
                                <h3><?= $completed_rides ?></h3>
                                <span>  {{trans('customize.completed'),' ',trans('customize.service')}}</span>
                            </div>
                    </div>
                 </div>
             </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 padding-right-0 padding-left-0">
                 <div class="r4_counter wid-stats db_box">
                    <div class="stats-data">
                         <i class="fa material-icons icon-primary pull-left" aria-hidden="true"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.cancelled_trip'));
                    echo $show->icon_code;
                    ?></i>
                        <div class="stats">
                                <h3> <?= $cancelled_rides ?></h3>
                                <span> {{ trans('customize.cancelled'),' ',trans('customize.service') }}s</span>
                            </div>
                    </div>
                 </div>
             </div>
             <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 padding-right-0 padding-left-0">
                 <div class="r4_counter wid-stats db_box">
                    <div class="stats-data">
                         <i class="fa material-icons icon-primary pull-left" aria-hidden="true"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.total_payment'));
                    echo $show->icon_code;
                    ?></i>
                        <div class="stats">
                                <h3> <?= $currency_sel ?> <?= sprintf2(($credit_payment + $card_payment + $cash_payment), 2) ?> </h3>
                                <span> {{trans('customize.total'),' ',trans('customize.payment')}} </span>
                            </div>
                    </div>
                 </div>
             </div>
       </div>
         <div class="col-md-12 col-sm-12 col-xs-12 padding-right-30 padding-left-20">
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 padding-right-0 padding-left-0 second_row">
                 <div class="r4_counter wid-stats db_box">
                    <div class="stats-data">
                         <i class="fa material-icons icon-primary pull-left" aria-hidden="true"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.card_payment'));
                    echo $show->icon_code;
                    ?></i>
                        <div class="stats">
                                <h3> <?= $currency_sel ?> <?= sprintf2($card_payment, 2) ?> </h3>
                                <span> {{trans('customize.card'),' ',trans('customize.payment')}}</span>
                            </div>
                    </div>
                 </div>
             </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 padding-right-0 padding-left-0">
                 <div class="r4_counter wid-stats db_box">
                    <div class="stats-data">
                         <i class="fa material-icons icon-primary pull-left" aria-hidden="true"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.credit_payment'));
                    echo $show->icon_code;
                    ?></i>
                        <div class="stats">
                                <h3>  <?= $currency_sel ?> <?= sprintf2($credit_payment, 2) ?> </h3>
                                <span>{{trans('customize.credit'),' ',trans('customize.payment')}}</span>
                            </div>
                    </div>
                 </div>
             </div>
        </div>
   </div>
<!--New dashboard code ends here-->



<!--<div class="row">
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-aqua">
            <div class="inner">
                <h3>
                    <?= $completed_rides + $cancelled_rides ?>
                </h3>
                <p>
                    Total Trips
                </p>
            </div>
            <div class="icon">
                <?php /* $icon = Keywords::where('keyword', 'total_trip')->first(); */ ?>
                <i class="fa"><?php
                    $show = Icons::find(Config::get('app.generic_keywords.total_trip'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-green">
            <div class="inner">
                <h3>
                    <?= $completed_rides ?>
                </h3>
                <p>
                    Completed {{ trans('customize.Trip');}}
                </p>
            </div>
            <div class="icon">
                <?php /* $icon = Keywords::where('keyword', 'completed_trip')->first(); */ ?>
                <i class="fa"><?php
                   
                    $show = Icons::find(Config::get('app.generic_keywords.completed_trip'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-red">
            <div class="inner">
                <h3>
                    <?= $cancelled_rides ?>
                </h3>
                <p>
                    Cancelled {{ trans('customize.Trip'); }}s
                </p>
            </div>
            <div class="icon">
                <?php /* $icon = Keywords::where('keyword', 'cancelled_trip')->first(); */ ?>
                <i class="fa"><?php
                    $show = Icons::find(Config::get('app.generic_keywords.cancelled_trip'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-purple">
            <div class="inner">
                <h3>
                    <?= $currency_sel ?> <?= sprintf2(($credit_payment + $card_payment + $cash_payment), 2) ?>
                </h3>
                <p>
                    Total Payment
                </p>
            </div>
            <div class="icon">
                <?php /* $icon = Keywords::where('keyword', 'total_payment')->first(); */ ?>
                <i class="fa"><?php
                    $show = Icons::find(Config::get('app.generic_keywords.total_payment'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-yellow">
            <div class="inner">
                <h3>
                    <?= $currency_sel ?> <?= sprintf2($card_payment, 2) ?>
                </h3>
                <p>
                    Card Payment
                </p>
            </div>
            <div class="icon">
                <?php /* $icon = Keywords::where('keyword', 'card_payment')->first(); */ ?>
                <i class="fa"><?php
                    $show = Icons::find(Config::get('app.generic_keywords.card_payment'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-maroon">
            <div class="inner">
                <h3>
                    <?= $currency_sel ?> <?= sprintf2($credit_payment, 2) ?>
                </h3>
                <p>
                    Credit Payment
                </p>
            </div>
            <div class="icon">
                <?php /* $icon = Keywords::where('keyword', 'credit_payment')->first(); */ ?>
                <i class="fa"><?php
                    $show = Icons::find(Config::get('app.generic_keywords.credit_payment'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div>
</div>-->



<!--  Summary end -->



<!-- filter start -->

<div class="box box-danger">
    <div class="box-header">
        <h3 class="box-title">{{trans('customize.filter');}}</h3>
    </div>
    <div class="box-body">
        <div class="row">

            <form role="form" method="get" action="{{ URL::Route('AdminReport') }}">

                <div class="col-md-6 col-sm-6 col-lg-6">
                    <input type="text" class="form-control" style="overflow:hidden;" id="start-date" name="start_date" value="{{ Input::get('start_date') }}" placeholder="{{trans('customize.start'),' ',trans('customize.date')}}">
                    <br>
                </div>

                <div class="col-md-6 col-sm-6 col-lg-6">
                    <input type="text" class="form-control" style="overflow:hidden;" id="end-date" name="end_date" placeholder="{{trans('customize.end'),' ',trans('customize.date')}}"  value="{{ Input::get('end_date') }}">
                    <br>
                </div>

                <div class="col-md-4 col-sm-4 col-lg-4">

                    <select name="status"  class="form-control">
                        <option value="0">{{trans('customize.status') }}</option>
                        <option value="1" <?php echo Input::get('status') == 1 ? "selected" : "" ?> >{{trans('customize.completed')}}</option>
                        <option value="2" <?php echo Input::get('status') == 2 ? "selected" : "" ?>>{{trans('customize.cancelled')}}</option>
                    </select>
                    <br>
                </div>

                <div class="col-md-4 col-sm-4 col-lg-4">

                    <select name="walker_id" style="overflow:hidden;" class="form-control">
                        <option value="0">{{trans('customize.provider')}}</option>
                        <?php foreach ($walkers as $walker) { ?>
                            <option value="<?= $walker->id ?>" <?php echo Input::get('walker_id') == $walker->id ? "selected" : "" ?>><?= $walker->first_name; ?> <?= $walker->last_name ?></option>
                        <?php } ?>
                    </select>
                    <br>
                </div>

                <div class="col-md-4 col-sm-4 col-lg-4">

                    <select name="owner_id" style="overflow:hidden;" class="form-control">
                        <option value="0">{{trans('customize.User')}}</option>
                        <?php foreach ($owners as $owner) { ?>
                            <option value="<?= $owner->id ?>" <?php echo Input::get('owner_id') == $owner->id ? "selected" : "" ?>><?= $owner->first_name; ?> <?= $owner->last_name ?></option>
                        <?php } ?>
                    </select>
                    <br>
                </div>


        </div>
    </div><!-- /.box-body -->
    <div class="box-footer">
        <button type="submit" name="submit" class="btn btn-flat btn-block btn-success board_btn" value="Filter_Data">{{trans('customize.filter'),' ',trans('customize.data')}}</button>
        <button type="submit" name="submit" class="btn btn-flat btn-block btn-success board_btn" value="Download_Report">{{trans('customize.download').' ',trans('customize.report')}}</button>
    </div>

</form>

</div>

<!-- filter end-->




<div class="box box-info tbl-box">
    <div align="left" id="paglink"><?php
        $t1=urldecode($walks->appends(array('type'=>Session::get('type')))->links());
        echo $t1;

        ?></div>
    <table class="table table-bordered">
        <tbody><tr>
                <th>{{ trans('customize.Request'),' ',trans('customize.id') }}</th>
                <th>{{ trans('customize.User'),' ',trans('customize.name')}} </th>
                <th>{{ trans('customize.Provider');}}</th>
                <th>{{ trans('customize.date') }}</th>
                <th>{{ trans('customize.time') }}</th>
                <th>{{ trans ('customize.status') }}</th>
                <th>{{ trans('customize.amount') }}</th>
                <th>{{ trans('customize.payment'),' ',trans('customize.status')}}</th>
                <th>{{ trans('customize.referral'),' ',trans('customize.bonus') }}</th>
                <th>{{ trans('customize.promotional'),' ',trans('customize.bonus') }}</th>
                <th>{{ trans('customize.card'),' ',trans('customize.payment') }}</th>
                <th>{{ trans('customize.cash'),' ',trans('customize.payment') }}</th>
            </tr>


            <?php foreach ($walks as $walk) { ?>

                <tr>
                    <td><?= $walk->id ?></td>

                    <td><?php echo $walk->owner_first_name . " " . $walk->owner_last_name; ?> </td>
                    <td>
                        <?php
                        if ($walk->confirmed_walker) {
                            echo $walk->walker_first_name . " " . $walk->walker_last_name;
                        } else {
                            echo "Un Assigned";
                        }
                        ?>
                    </td>
                    <td><?php echo date("d M Y", strtotime($walk->date)); ?></td>
                    <td><?php echo date("g:iA", strtotime($walk->date)); ?></td>

                    <td>
                        <?php
                        if ($walk->is_cancelled == 1) {

                            echo "<span class='badge bg-red'>".trans('customize.cancelled')."</span>";
                        } elseif ($walk->is_completed == 1) {
                            echo "<span class='badge bg-green'>".trans('customize.completed')."</span>";
                        } elseif ($walk->is_started == 1) {
                            echo "<span class='badge bg-yellow'>".trans('customize.started')."</span>";
                        } elseif ($walk->is_walker_arrived == 1) {
                            echo "<span class='badge bg-yellow'>".trans('customize.walker').' '.trans('customize.arrived')."</span>";
                        } elseif ($walk->is_walker_started == 1) {
                            echo "<span class='badge bg-yellow'>".trans('customize.walker').' '.trans('customize.started')."</span>";
                        } else {
                            
                        }
                        ?>
                    </td>
                    <td>
                        <?php echo sprintf2($walk->total, 2); ?>
                    </td>
                    <td>
                        <?php
                        if ($walk->is_paid == 1) {

                            echo "<span class='badge bg-green'>".trans('customize.completed')."</span>";
                        } elseif ($walk->is_paid == 0 && $walk->is_completed == 1) {
                            echo "<span class='badge bg-red'>".trans('customize.pending')."</span>";
                        } else {
                            echo "<span class='badge bg-yellow'>".trans('customize.request_not_completed')."</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <?= sprintf2($walk->ledger_payment, 2); ?>
                    </td>
                    <td>
                        <?= sprintf2($walk->promo_payment, 2); ?>
                    </td>
                    <?php if ($walk->payment_mode == 1) { ?>
                        <td>
                            <?= sprintf2(0, 2); ?>
                        </td>
                    <?php } else { ?>
                        <td>
                            <?= sprintf2($walk->card_payment, 2); ?>
                        </td>
                        <?php
                    }
                    if ($walk->payment_mode == 1) {
                        ?>
                        <td>
                            <?= sprintf2($walk->card_payment, 2); ?>
                        </td>
                    <?php } else { ?>
                        <td>
                            <?= sprintf2(0, 2); ?>
                        </td>
                    <?php } ?>
                </tr>
            <?php } ?>

        </tbody>
    </table>
    <div align="left" id="paglink"><?php
        $t1=urldecode($walks->appends(array('type'=>Session::get('type')))->links());
        echo $t1;
        ?></div>
</div>
<!--</form>-->
</div>
</div>
</div>

<script>
    $(function () {
        $("#start-date").datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $("#end-date").datepicker("option", "minDate", selectedDate);
            }
        });
        $("#end-date").datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $("#start-date").datepicker("option", "maxDate", selectedDate);
            }
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#myModal").modal('show');
    });
</script>

@stop