@extends('layout')

@section('content')

@if (Session::has('msg'))
<h4 class="alert alert-info">
    {{{ Session::get('msg') }}}
    {{{Session::put('msg',NULL)}}}
</h4>
@endif
<div class="box box-primary">
    <div class="box-header">
        <h3 class="box-title">{{ trans('customize.edit'),' ', trans('customize.promo_code') }}</h3>
    </div><!-- /.box-header -->
    <!-- form start -->
    <form role="form" id="form" method="post" action="{{ URL::Route('AdminPromoUpdate') }}"  enctype="multipart/form-data">
        <input type="hidden" name="id" value="{{$promo_code->id}}">
        <div class="box-body">
            <div class="form-group col-md-6 col-sm-6">
                <label>{{ trans('customize.promo_code'),' ',trans('customize.name') }}</label>
                <input type="text" class="form-control" name="code_name" value="{{$promo_code->coupon_code}}" placeholder="{{ trans('customize.promo_code'),' ',trans('customize.name') }}" >
            </div>
            <div class="form-group col-md-6 col-sm-6">
                <label>{{ trans('customize.promo_code'),' ',trans('customize.value') }}</label>
                <span id="no_amount_error1" style="display: none"></span>
                <input class="form-control" type="text" name="code_value" value="{{$promo_code->value}}" placeholder="20" onkeypress="return Isamount(event, 1);">
            </div>
            <div class="form-group col-md-6 col-sm-6">
                <label>{{ trans('customize.promo_code'),' ',trans('customize.type') }}</label>
                <select name="code_type" class="form-control">
                    <option value="1" <?php
                    if ($promo_code->type == 1) {
                        echo "selected";
                    }
                    ?>>{{ trans('customize.percent')}}</option>
                    <option value="2" <?php
                    if ($promo_code->type == 2) {
                        echo "selected";
                    }
                    ?>>{{ trans('customize.absolute')}}</option>
                </select>
            </div>
            <div class="form-group col-md-6 col-sm-6">
                <label>{{ trans('customize.uses_allowed')}}</label>
                <span id="no_number_error1" style="display: none"> </span>
                <input class="form-control" type="text" name="code_uses" value="{{$promo_code->uses}}" placeholder="50" onkeypress="return IsNumeric(event, 1);">
            </div>
            <div class="form-group col-md-6 col-sm-6">
                <label>Start Date</label>
                <br>
                <input type="text" class="form-control" style="overflow:hidden;" id="start-date" name="start_date" value="{{date("m/d/Y", strtotime(trim($promo_code->start_date)))}}" placeholder="{{ trans('customize.start'),' ',trans('customize.date') }}">
                <!--<div class='input-group date' id='startDate'>
                    <input type='text' class="form-control" name="code_expiry" value="{{date("m/d/Y", strtotime(trim($promo_code->expiry)))}}">
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>-->
            </div>
            <div class="form-group col-md-6 col-sm-6">
                <label>Expiry Date</label>
                <br>
                <input type="text" class="form-control" style="overflow:hidden;" id="end-date" name="code_expiry" placeholder="{{ trans('customize.expiry'),' ',trans('customize.date') }}"  value="{{date("m/d/Y", strtotime(trim($promo_code->expiry)))}}">
                <!--<div class='input-group date' id='startDate'>
                    <input type='text' class="form-control" name="code_expiry" value="{{date("m/d/Y", strtotime(trim($promo_code->expiry)))}}">
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>-->
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary btn-flat btn-block">{{ trans('customize.update'),' ',trans('customize.change') }}</button>
            </div>
        </div>
</div>
</form>
</div>

<script type="text/javascript">
    $("#form").validate({
        rules: {
            code_name: "required",
            code_value: "required",
            code_uses: "required",
            code_expiry: "required",
        }
    });

</script>

<script type="text/javascript">

    jQuery(function () {
        jQuery('#startDate').datetimepicker();
        jQuery("#startDate").on("dp.change", function (e) {
            jQuery('#endDate').data("DateTimePicker").setMinDate(e.date);
        });
        jQuery("#endDate").on("dp.change", function (e) {
            jQuery('#startDate').data("DateTimePicker").setMaxDate(e.date);
        });
    });

</script>

<script type="text/javascript" src="{{asset('javascript/moment.js')}}"></script>
<script type="text/javascript" src="{{asset('javascript/bootstrap-datetimepicker.js')}}"></script>

@stop