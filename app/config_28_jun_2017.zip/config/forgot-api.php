<html>
<head>
</head>
<body>
<form action="http://taxiclone.com/demo/public/user/addcardtoken" method="post">
<input type="text" name="last_four" value="4242">
<input type="text" name="token" value="2y10Cyw6JJW1x796dnZsrUpMPO0gfQE4NnP0w7WrJYqlh09BHf1LkKk6q">
<input type="text" name="id" value="12">
<input type="text" name="payment_token" value="tok_17csYrFZNNWvW0BClkgWDXev">
<input type="submit" name="submit" value"submit">
</form>
</body>
</html>