<?php
return array(

    'Dashboard' => 'Dashboard',
    'map_view' => 'Map View',
    'Reviews' => 'Reviews',
    'Information' => 'Information',
    'Types' => 'Types',
    'Documents' => 'Documents',
    'promo_codes' => 'Promo Codes',
    'Customize' => 'Customize',
    'payment_details' => 'Payment Details',
    'Settings' => 'Settings',
    'Admin' => 'Admin',
    'admin_control' => 'Admin Control',
    'log_out' => 'Log Out',
    'Provider' => 'Driver',
    'User' => 'User',
    'Taxi' => 'Taxi',
    'Trip' => 'Service',
    'Walk' => 'Walk',
    'Request' => 'Request',
);
