<?php
return array(

    'Dashboard' => 'Dashboard',
    'map_view' => 'Map view',
    'Reviews' => 'Note',
    'Information' => 'Information',
    'Types' => 'Vehicle types',
    'Documents' => 'Documents',
    'promo_codes' => 'Promo Codes',
    'Customize' => 'Customize',
    'payment_details' => 'Payment Details',
    'Settings' => 'Settings',
    'Admin' => 'Administrator',
    'admin_control' => 'Admin Control',
    'log_out' => 'Logout',
    'Provider' => 'Driver',
    'User' => 'User',
    'Taxi' => 'Taxi',
    'Trip' => 'Service',
    'Walk' => 'Walk',
    'Request' => 'Request',
	'privilege' => 'Privilege',
	'dispatcher' => 'Dispatcher Panel'
);
