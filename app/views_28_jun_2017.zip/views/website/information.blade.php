@extends('website.layout')

    @section('content')
        <blockquote style="margin-right: 0px;" dir="ltr"><blockquote style="margin-right: 0px;" dir="ltr"><h4 align="left">Heureuse que cela fonctionne.</h4></blockquote></blockquote>
    @stop

