@extends('website.layout')

    @section('content')
        Champagne
    @stop

