@extends('website.layout')

    @section('content')
        Test
    @stop

