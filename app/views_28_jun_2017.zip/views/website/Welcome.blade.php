@extends('website.layout')

    @section('content')
        <font color="#000000">                                              
                                        Welcome to Just Ride</font> 
    @stop

