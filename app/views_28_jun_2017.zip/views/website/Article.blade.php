@extends('website.layout')

    @section('content')
        <font style="background-color: rgb(102, 102, 153);">                                              
                                        Article</font>
    @stop

