@extends('layout')

@section('content')

    <!-- will be used to show any messages -->
    @if (Session::has('message'))
        <div class="alert alert-success">{{ Session::get('message') }}</div>
    @endif
    <br>


    <div class="box box-danger">

        <form method="get" action="{{ URL::Route('searchSettlements', 0) }}">
            <div class="box-header">
                <h3 class="box-title">Filter</h3>
            </div>
            <div class="box-body row">
                <div class="col-md-6 col-sm-12">
                    <select name="walker_id" style="overflow:hidden;" class="form-control">
                        <option value="0">Provider</option>
                        <?php foreach ($walkers as $walker) { ?>
                        <option value="<?= $walker->id ?>" <?php echo Input::get('walker_id') == $walker->id ? "selected" : "" ?>><?= $walker->first_name; ?> <?= $walker->last_name ?></option>
                        <?php } ?>
                    </select>
                    <br>
                </div>
            </div>

            <div class="box-footer">
                <button type="submit" id="btnsearch" class="btn btn-flat btn-block btn-success serach_blad">Search
                </button>
            </div>
        </form>
    </div>



    <div class="box box-info tbl-box">
        <form method="get" id="wallet" action="{{ URL::Route('updateSettlements', Input::get('walker_id')) }}">
        <table class="table table-bordered">
            <tbody>
            <tr>
                <th><input type="checkbox" id="select_all"/> Selecct All </th>
                <th>S.No</th>
                <th>Walker Name</th>
                <th>Request ID</th>
                <th>Total</th>
                <th>Driver Payments</th>
            </tr>
            <?php
               $driverTotal = $total = 0;
            if(count($settlements) > 0 && !empty($walker_id)) :
            $i = 1; foreach ($settlements as $settlement) { ?>

            <tr>
                <td><input class="checkbox walletchk" type="checkbox" name="settlements_<?php echo $settlement->id;?>" value="yes" style="margin-left: 67px;">
                    <input type="hidden" name="type[][<?php echo $settlement->id;?>]" class="form-control" placeholder="type" value="{{ $i }}">
                    <br>
                </td>
                <td><?= $i; ?></td>
                <td><?php $walkers = DB::table('walker')->where('id', '=', $settlement->confirmed_walker)->first();
                    echo(!empty($walkers->first_name) ? $walkers->first_name . " " . $walkers->last_name : ''); ?>
                    <input type="hidden" name="walker_id_<?php echo $settlement->id;?>" class="form-control" placeholder="Walker id" value="{{ $settlement->confirmed_walker }}"><br>
                </td>
                <td><?= $settlement->id ?></td>
                <td><?= $settlement->total ?>
                  <input type="hidden" name="total_<?php echo $settlement->id;?>" class="form-control" placeholder="total" value="{{ $settlement->total }}"><br>
                </td>
                <td><?= (!empty($settlement->driver_per_payment) ? $settlement->driver_per_payment : ''); ?>
                    <input type="hidden" name="driver_per_payment_<?php echo $settlement->id;?>" class="form-control" placeholder="Driver Per Payment" value="{{ $settlement->driver_per_payment }}"><br>
                </td>
            </tr>
            <?php $i++;
                 $total += $settlement->total;
                 $driverTotal += $settlement->driver_per_payment;
            } ?>
             <tr>
                 <td colspan="4"></td>
                 <td><strong> Total :</strong> <?php echo $total; ?></td>
                 <td><strong> Driver Total :</strong> <?php echo $driverTotal; ?></td>
             </tr>
            <?php else : ?>
            <tr>
                <td colspan="6">No Records Found</td>
            </tr>
            <?php endif; ?>
            <?php if(count($settlements) > 0 && !empty($walker_id)) : ?>
            <tr>
                <td colspan="6"><button type="button" id="btnsearch" onclick="validate()" class="btn btn-flat btn-block btn-success serach_blad">Update</button></td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>

        </form>
    </div>

    <script type="text/javascript">

         function validate() {

            var checkedValue = document.querySelectorAll('.checkbox:checked').length;
            if (checkedValue >= 1){
                document.getElementById("wallet").submit();
            }else{
                alert("You didn't check it! Let me check atleast one checkbox.");
                return false;
            }

        }


        var select_all = document.getElementById("select_all"); //select all checkbox
        var checkboxes = document.getElementsByClassName("checkbox"); //checkbox items

        //select all checkboxes
        select_all.addEventListener("change", function(e){
            for (i = 0; i < checkboxes.length; i++) {
                checkboxes[i].checked = select_all.checked;
            }
        });

        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].addEventListener('change', function(e){ //".checkbox" change
                //uncheck "select all", if one of the listed checkbox item is unchecked
                if(this.checked == false){
                    select_all.checked = false;
                }
                //check "select all" if all checkbox items are checked
                if(document.querySelectorAll('.checkbox:checked').length == checkboxes.length){
                    select_all.checked = true;
                }
            });
        }
    </script>
@stop
