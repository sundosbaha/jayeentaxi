@extends('layout')

@section('content')


    <!--   summary start -->
    <style>
        .blue {
            color: #f9f9f9;
            background: red;
            background: -webkit-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: -o-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: -moz-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);;
        }

        .light-blue {
            color: #f9f9f9;
            background: red;
            background: -webkit-linear-gradient(141deg, #10a1b8 0%, #699edb 51%, #6d95e8 75%);
            background: -o-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: -moz-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: linear-gradient(141deg, #10a1b8 0%, #699edb 51%, #6d95e8 75%);
        }

        .green {
            color: #f9f9f9;
            background: red;
            background: -webkit-linear-gradient(141deg, #06b889 0%, #4cdbc1 51%, #91e8cc 75%);
            background: -o-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: -moz-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
            background: linear-gradient(141deg, #5bb8b1 0%, #3ddbc1 51%, #2cb5e8 75%);
        }

        #hideMe {
            -moz-animation: cssAnimation 0s ease-in 5s forwards;
            /* Firefox */
            -webkit-animation: cssAnimation 0s ease-in 5s forwards;
            /* Safari and Chrome */
            -o-animation: cssAnimation 0s ease-in 5s forwards;
            /* Opera */
            animation: cssAnimation 0s ease-in 5s forwards;
            -webkit-animation-fill-mode: forwards;
            animation-fill-mode: forwards;
        }

        @keyframes cssAnimation {
            to {
                width: 0;
                height: 0;
                overflow: hidden;
            }
        }

        @-webkit-keyframes cssAnimation {
            to {
                width: 0;
                height: 0;
                visibility: hidden;
            }
        }

        .alert {
            padding: 20px;
            background-color: #2fe41d; /* green */
            color: white;
            margin-bottom: 15px;
            opacity: 0.6;
        }

    </style>

    <?php

    if (Session::has('message')) {
        echo '<div class="alert" id="hideMe">' . Session::get('message') . '</div>';
    }
    ?>



    <div class="row extra_detail">
        <div class="col-lg-4 col-xs-6">
            <!-- small box -->
            <div class="small-box blue">
                <div class="inner">
                    <h3>
                        <?= $wallet_total; ?>
                    </h3>
                    <p>
                        Total Amount Added
                    </p>
                </div>
                <div class="icon" style="color:#c5d0dd;">
                    <?php /* $icon = Keywords::where('keyword', 'total_payment')->first(); */ ?>
                    <i class="fa"><?php
                        /* $show = Icons::find($icon->alias); */
                        $show = Icons::find(Config::get('app.generic_keywords.total_payment'));
                        echo $show->icon_code;
                        ?></i>
                </div>

            </div>
        </div><!-- ./col -->

        <div class="col-lg-4 col-xs-6">
            <!-- small box -->
            <div class="small-box light-blue">
                <div class="inner">
                    <h3>
                        <?= $wallet_spend ?>
                    </h3>
                    <p>
                        Total Amount Spent
                    </p>
                </div>
                <div class="icon" style="color:#c5d0dd;">
                    <?php /* $icon = Keywords::where('keyword', 'total_payment')->first(); */ ?>
                    <i class="fa"><?php
                        /* $show = Icons::find($icon->alias); */
                        $show = Icons::find(Config::get('app.generic_keywords.total_payment'));
                        echo $show->icon_code;
                        ?></i>
                </div>

            </div>
        </div><!-- ./col -->


        <div class="col-lg-4 col-xs-6">
            <!-- small box -->
            <div class="small-box green">
                <div class="inner">
                    <h3>
                        <?= $wallet_balance;  ?>
                    </h3>
                    <p>
                        Balance Amount
                    </p>
                </div>
                <div class="icon" style="color:#c5d0dd;">
                    <i class="fa fa-money" aria-hidden="true"></i>
                </div>

            </div>
        </div><!-- ./col -->


    </div>


    <div class="box box-danger">
        <div class="box-header">
            <h3 class="box-title">Filter</h3>
        </div>
        <div class="box-body">
            <div class="row">

                <form role="form" method="get" id="form-search" action="">

                    <input type="hidden" name="walker_id" value="<?php echo $walker_id; ?>">
                    <input type="hidden" name="tab" id="tab-new" value="1">
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <input type="text" class="form-control" style="overflow:hidden;" id="start-date"
                               name="start_date" value="{{ Input::get('start_date') }}" placeholder="Start Date">
                        <br>
                    </div>

                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <input type="text" class="form-control" style="overflow:hidden;" id="end-date" name="end_date"
                               placeholder="End Date" value="{{ Input::get('end_date') }}">
                        <br>
                    </div>

            </div>
        </div><!-- /.box-body -->
        <div class="box-footer">
            <button type="submit" name="submit" class="btn btn-flat btn-block btn-success board_btn"
                    value="Filter_Data">Filter Data
            </button>
            <button type="submit" name="submit" class="btn btn-flat btn-block btn-success board_btn"
                    value="Download_Report">Download Report
            </button>
        </div>

        </form>

    </div>
    <!--  Summary end -->
    <!-- filter start -->

    <!-- filter end-->

    <style>

        .custom-box {
            margin-top: 20px;
            border-bottom: 5px solid red;
            padding: 6px;
            color: #000;
            cursor: pointer;
        }

        .extra_space {
            padding: 10px 241px;

        }

        .top_line {
            border-top: 1px solid red;
        }

        .tab-selection {
            background: #e38888;
        }
    </style>






    <div class="row">
        <div class="col-lg-4 col-xs-6">
            <div class="custom-box  custom-tab" data-id="1">
                <i class="fa fa-cog" aria-hidden="true"></i> {{ trans('customize.walker_wallet_history');}}
                <i class="fa fa-arrows-alt full-screen" aria-hidden="true" style="float: right;"></i>
            </div>
        </div>
        <div class="col-lg-4 col-xs-6">
            <div class="custom-box custom-tab" data-id="2">
                <i class="fa fa-cog" aria-hidden="true"></i> {{ trans('customize.walker_spend_history');}}
                <i class="fa fa-arrows-alt full-screen" aria-hidden="true" style="float: right;"></i>
            </div>
        </div>
    </div>

    <!-- form start -->

    <div class="box box-info tbl-box" id="tab1">
        <div align="left" id="paglink">
            <?php
            $t1 = urldecode($walletHistory->appends(array('walker_id'=>$walker_id,'start_date'=>Input::get('start_date'),'end_date'=>Input::get('end_date'),'submit'=>Input::get('submit'),'tab'=>1))->links());
            echo $t1;
            ?>
        </div>
        <table class="table table-bordered">
            <tbody>
            <tr>
                <th>{{ trans('customize.s_no');}}</th>
                <th>{{ trans('customize.unique_id');}}</th>
                <th>{{ trans('customize.amount');}}</th>
                <th>{{ trans('customize.date');}}</th>
                <th>{{ trans('customize.time');}}</th>
            </tr>
            <?php
              $i = 1;
            if(count($walletHistory) > 0) :
                foreach($walletHistory as $wallet) :
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $wallet->walker_history_id; ?></td>
                    <td><?php echo $wallet->amount; ?></td>
                    <td><?php echo date('m/d/Y',strtotime($wallet->created_at)); ?></td>
                    <td><?php echo date('h:i:s a',strtotime($wallet->created_at)); ?></td>
                </tr>
                <?php $i++;
                endforeach;
            else :
            ?>
            <tr>
                <td colspan="6">No Records Found</td>
            </tr>
            <?php
            endif;
            ?>
            </tbody>
        </table>
        <div align="left" id="paglink">
            <?php
            $t1 = urldecode($walletHistory->appends(array('walker_id'=>$walker_id,'start_date'=>Input::get('start_date'),'end_date'=>Input::get('end_date'),'submit'=>Input::get('submit'),'tab'=>1))->links());
            echo $t1;
            ?>
        </div>
    </div>


    <div class="box box-info tbl-box" id="tab2">
        <div align="left" id="paglink">
            <?php $t1 = urldecode($walletSpendHistory->appends(array('walker_id'=>$walker_id,'start_date'=>Input::get('start_date'),'end_date'=>Input::get('end_date'),'submit'=>Input::get('submit'),'tab'=>2))->links());
            echo $t1; ?>
        </div>
        <table class="table table-bordered">
            <tbody>
            <tr>
                <th>{{ trans('customize.s_no');}}</th>
                <th>{{ trans('customize.unique_id');}}</th>
                <th>{{ trans('customize.spend_amount');}}</th>
                <th>{{ trans('customize.date');}}</th>
                <th>{{ trans('customize.time');}}</th>
            </tr>
            <?php
            $j = 1;
            if(count($walletSpendHistory) > 0) :
            foreach($walletSpendHistory as $wallet) :
            ?>
            <tr>
                <td><?php echo $j; ?></td>
                <td><?php echo $wallet->spend_history_id; ?></td>
                <td><?php echo $wallet->amount; ?></td>
                <td><?php echo date('m/d/Y',strtotime($wallet->created_at)); ?></td>
                <td><?php echo date('h:i:s a',strtotime($wallet->created_at)); ?></td>
            </tr>
            <?php $j++;
            endforeach;
            else :
            ?>
            <tr>
                <td colspan="6">No Records Found</td>
            </tr>
            <?php
            endif;
            ?>
            </tbody>
        </table>
        <div align="left" id="paglink"><?php
            $t1 = urldecode($walletSpendHistory->appends(array('walker_id'=>$walker_id,'start_date'=>Input::get('start_date'),'end_date'=>Input::get('end_date'),'submit'=>Input::get('submit'),'tab'=>2))->links());
            echo $t1;
            ?></div>
    </div>
    <!--</form>-->


    <script>

        $('#form-search').submit(function (e) {
            $('#tab-new').val($('.tab-selection').attr('data-id') ? $('.tab-selection').attr('data-id') : 1);
            return true;
        });

        $(document).ready(function (e) {
            var tab = <?= $tab ? $tab: 1; ?>;
            $.each($('.custom-tab'), function (key, value) {
                if (value.attributes[1].nodeValue == tab) {

                    value.className += ' tab-selection';
                }
            });
            if (tab == 1) {

                $('#tab1').show();
                $('#tab2').hide();
            }
            if (tab == 2) {
                $('#tab1').hide();
                $('#tab2').show();
            }

        });

        $('.custom-tab').click(function (e) {
            $('.custom-tab').removeClass('tab-selection');
            $(this).addClass('tab-selection');

            if ($(this).attr("data-id") == 1) {
                $('#tab1').show();
                $('#tab2').hide();
            }
            else {
                $('#tab1').hide();
                $('#tab2').show();
            }
        });

        $('#basic-form').submit(function () {
            var wallet_limit = $('#wallet_limit_per_user');
            var wallet_limit_add = $('#wallet_limit_per_add');

            if (wallet_limit.val() == '') {
                wallet_limit.focus();
                wallet_limit.val('');
                alert('Wallet limit per user is required');
                return false;
            }
            else if (!$.isNumeric(wallet_limit.val())) {
                wallet_limit.focus();
                wallet_limit.val('');
                alert('Wallet limit per user is must be a number');
                return false;
            }
            else if (wallet_limit.val() > 10000) {
                wallet_limit.focus();
                wallet_limit.val('');
                alert('Wallet limit per user is must be less than 10,000');
                return false;
            }

            if (wallet_limit_add.val() == '') {
                wallet_limit_add.focus();
                wallet_limit_add.val('');
                alert('Wallet limit per add is required');
                return false;
            }
            else if (!$.isNumeric(wallet_limit_add.val())) {
                wallet_limit_add.focus();
                wallet_limit_add.val('');
                alert('Wallet limit per add is must be a number');
                return false;
            }
            else if (wallet_limit_add.val() > 10000) {
                wallet_limit_add.focus();
                wallet_limit_add.val('');
                alert('Wallet limit per add is must be less than 10,000');
                return false;
            }

            return true;
        });


        $('.full-screen').click(function (e) {
            if ($('.extra_detail:visible').length == 0) {
                $('.extra_detail').show(1000);
            } else {
                $('.extra_detail').hide(1000);
            }
        });

        $(function () {
            $("#start-date").datepicker({
                defaultDate: "+1w",
                changeMonth: true,
                numberOfMonths: 1,
                onClose: function (selectedDate) {
                    $("#end-date").datepicker("option", "minDate", selectedDate);
                }
            });
            $("#end-date").datepicker({
                defaultDate: "+1w",
                changeMonth: true,
                numberOfMonths: 1,
                onClose: function (selectedDate) {
                    $("#start-date").datepicker("option", "maxDate", selectedDate);
                }
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#myModal").modal('show');
        });
    </script>

@stop