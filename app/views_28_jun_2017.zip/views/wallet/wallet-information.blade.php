@extends('layout')

@section('content')


<!--   summary start -->
<style>
    .blue{
        color: #f9f9f9;
        background: red;
        background: -webkit-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: -o-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: -moz-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);;
    }
    .light-blue{
        color: #f9f9f9;
        background: red;
        background: -webkit-linear-gradient(141deg, #10a1b8 0%, #699edb 51%, #6d95e8 75%);
        background: -o-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: -moz-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: linear-gradient(141deg, #10a1b8 0%, #699edb 51%, #6d95e8 75%);
    }
    .green{
        color: #f9f9f9;
        background: red;
        background: -webkit-linear-gradient(141deg, #06b889 0%, #4cdbc1 51%, #91e8cc 75%);
        background: -o-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: -moz-linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
        background: linear-gradient(141deg, #5bb8b1 0%, #3ddbc1 51%, #2cb5e8 75%);
    }

    #hideMe {
        -moz-animation: cssAnimation 0s ease-in 5s forwards;
        /* Firefox */
        -webkit-animation: cssAnimation 0s ease-in 5s forwards;
        /* Safari and Chrome */
        -o-animation: cssAnimation 0s ease-in 5s forwards;
        /* Opera */
        animation: cssAnimation 0s ease-in 5s forwards;
        -webkit-animation-fill-mode: forwards;
        animation-fill-mode: forwards;
    }
    @keyframes cssAnimation {
        to {
            width:0;
            height:0;
            overflow:hidden;
        }
    }
    @-webkit-keyframes cssAnimation {
        to {
            width:0;
            height:0;
            visibility:hidden;
        }
    }

    .alert {
        padding: 20px;
        background-color: #2fe41d; /* green */
        color: white;
        margin-bottom: 15px;
        opacity: 0.6;
    }

</style>

<?php

        if(Session::has('message'))
            {
                echo '<div class="alert" id="hideMe">'.Session::get('message').'</div>';
            }
?>



<div class="row extra_detail">
    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box blue">
            <div class="inner">
                <h3>
                    <?= $wallet_total; ?>
                </h3>
                <p>
                    Total Amount Added
                </p>
            </div>
            <div class="icon" style="color:#c5d0dd;">
                <?php /* $icon = Keywords::where('keyword', 'total_payment')->first(); */ ?>
                <i class="fa"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.total_payment'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div><!-- ./col -->

    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box light-blue" >
            <div class="inner">
                <h3>
                    <?= $wallet_spend ?>
                </h3>
                <p>
                    Total Amount Spent
                </p>
            </div>
            <div class="icon" style="color:#c5d0dd;">
                <?php /* $icon = Keywords::where('keyword', 'total_payment')->first(); */ ?>
                <i class="fa"><?php
                    /* $show = Icons::find($icon->alias); */
                    $show = Icons::find(Config::get('app.generic_keywords.total_payment'));
                    echo $show->icon_code;
                    ?></i>
            </div>

        </div>
    </div><!-- ./col -->


    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box green" >
            <div class="inner">
                <h3>
                    <?= $wallet_balance;  ?>
                </h3>
                <p>
                    Balance Amount
                </p>
            </div>
            <div class="icon" style="color:#c5d0dd;">
                <i class="fa fa-money" aria-hidden="true"></i>
            </div>

        </div>
    </div><!-- ./col -->




    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box light-blue" >
            <div class="inner">
                <h3>
                    <?= $wallet_limit ?>
                </h3>
                <p>
                    Wallet Limit
                </p>
            </div>
            <div class="icon" style="color:#c5d0dd;">
                <i class="fa fa-money" aria-hidden="true"></i>
            </div>

        </div>
    </div><!-- ./col -->


    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box blue" >
            <div class="inner">
                <h3>
                    <?= ucwords($payment)  ?>
                </h3>
                <p>
                    Type of Payment
                </p>
            </div>
            <div class="icon" style="color:#c5d0dd;">
                <i class="fa fa-money" aria-hidden="true"></i>
            </div>

        </div>
    </div><!-- ./col -->


</div>
<!--  Summary end -->
<!-- filter start -->

<!-- filter end-->

 <style>

     .custom-box {
         margin-top: 20px;
         border-bottom: 5px solid red;
         padding: 6px;
         color: #000;
     }
     .extra_space{
         padding: 10px 241px;

     }
     .top_line {
         border-top: 1px solid red;
     }
 </style>

    <div class="row">
        <div class="col-lg-4 col-xs-6">
            <div class="custom-box" >
                <i class="fa fa-cog" aria-hidden="true"></i> Wallet Setting
                <i class="fa fa-arrows-alt full-screen" aria-hidden="true" style="float: right;"></i>

            </div>
            </div>
        </div>

    <!-- form start -->


    <form method="post" id="basic-form" action="{{ URL::Route('AdminWalletInformation') }}"  enctype="multipart/form-data">
    <div class="box-body top_line">
        <p style="color:red;">
            @foreach ($errors->all() as $error)
                <?php echo $error; ?>
                <br/>
            @endforeach
        </p>

        <div class="form-group extra_space">
            <label>Set Wallet Limit per User</label>
            <input type="text" id="wallet_limit_per_user" name="wallet_limit_per_user" class="form-control" value="<?= $wallet_limit_per_user ?>" placeholder="Set Wallet Limit per User" value="">
        </div>

        <div class="form-group extra_space">
            <label>Set Wallet Amount per Add</label>
            <input type="text" id="wallet_limit_per_add" name="wallet_limit_per_add" class="form-control" value="<?= $wallet_limit_per_add ?>" placeholder="Set Wallet Amount per Add" value="">
        </div>
    </div>


        <div class="form-group extra_space">
            <label>Trip Mini Amount Limit</label>
            <input type="text" id="wallet_limit_per_add" name="wallet_limit_per_trip" class="form-control" value="<?= $trip_limit ?>" placeholder="Set Wallet Amount per Add" value="">
        </div>
        </div>

    <div class="box-footer extra_space_high">

        <button id="add_info" type="submit" class="btn btn-primary btn-flat btn-block">Save</button>
    </div>
    </form>
    </div>








<!--</form>-->
</div>
</div>
</div>


<script>

    $('#basic-form').submit(function(){
        var wallet_limit =  $('#wallet_limit_per_user');
        var wallet_limit_add =  $('#wallet_limit_per_add');

       if(wallet_limit.val() == '')
       {
           wallet_limit.focus();
           wallet_limit.val('');
           alert('Wallet limit per user is required');
           return false;
       }
       else if(!$.isNumeric(wallet_limit.val())){
           wallet_limit.focus();
           wallet_limit.val('');
           alert('Wallet limit per user is must be a number');
           return false;
       }
       else if(wallet_limit.val() > 10000)
       {
           wallet_limit.focus();
           wallet_limit.val('');
           alert('Wallet limit per user is must be less than 10,000');
           return false;
       }

        if(wallet_limit_add.val() == '')
        {
            wallet_limit_add.focus();
            wallet_limit_add.val('');
            alert('Wallet limit per add is required');
            return false;
        }
        else if(!$.isNumeric(wallet_limit_add.val())){
            wallet_limit_add.focus();
            wallet_limit_add.val('');
            alert('Wallet limit per add is must be a number');
            return false;
        }
        else if(wallet_limit_add.val() > 10000)
        {
            wallet_limit_add.focus();
            wallet_limit_add.val('');
            alert('Wallet limit per add is must be less than 10,000');
            return false;
        }

        return true;
    });


    $('.full-screen').click(function(e){
        if($('.extra_detail:visible').length == 0)
        {
            $('.extra_detail').show(1000);
        }else {
            $('.extra_detail').hide(1000);
        }
    });

    $(function () {
        $("#start-date").datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $("#end-date").datepicker("option", "minDate", selectedDate);
            }
        });
        $("#end-date").datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $("#start-date").datepicker("option", "maxDate", selectedDate);
            }
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#myModal").modal('show');
    });
</script>

@stop