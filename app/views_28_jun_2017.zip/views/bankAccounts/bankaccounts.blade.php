@extends('layout')

@section('content')

    <!-- will be used to show any messages -->
    @if (Session::has('message'))
        <div class="alert alert-success">{{ Session::get('message') }}</div>
    @endif
    <div id="addbutton">
        <a id="addinfo" href="{{ URL::Route('AdminProviderBanking', $walker_id) }}">
            <button type="submit" id="newpage" class="btn btn-flat btn-block btn-success" value="Add New Page">Add Bank
                Accounts
            </button>
        </a>
    </div>


    <br>


    <!-- <div class="box box-danger">

                       <form method="get" action="{{ URL::Route('/admin/searchinfo', 0) }}">
                                <div class="box-header">
                                    <h3 class="box-title">Filter</h3>
                                </div>
                                <div class="box-body row">

                                <div class="col-md-6 col-sm-12">

                                <select id="searchdrop" class="form-control" name="type">
                                    <option value="infoid" id="infoid">ID</option>
                                    <option value="infotitle" id="infotitle">Title</option>
                                </select>

                                               
                                    <br>
                                </div>
                                <div class="col-md-6 col-sm-12">

                                    <input class="form-control" type="text" name="valu" id="insearch" placeholder="keyword"/>
                                    <br>
                                </div>

                                </div>

                                <div class="box-footer">

                                  
                                        <button type="submit" id="btnsearch" class="btn btn-flat btn-block btn-success serach_blad">Search</button>

                                        
                                </div>
                        </form>

                    </div> -->



    <div class="box box-info tbl-box">
        <table class="table table-bordered">
            <tbody>
            <tr>
                <th>S.No</th>
                <th>Walker Name</th>
                <th>Merchant ID</th>
                <th>Account Number</th>
                <th>Routing Number</th>
                <th>SSN</th>
                <th>Actions</th>
            </tr>

            <?php
            if(count($bankAccounts) > 0) :
            $i = 1; foreach ($bankAccounts as $bankAccount) { ?>
            <tr>
                <td><?= $i; ?></td>
                <td><?php $walkers = DB::table('walker')->where('id', '=', $bankAccount->walker_id)->first();
                    echo(!empty($walkers->first_name) ? $walkers->first_name . " " . $walkers->last_name : ''); ?> </td>
                <td><?= $bankAccount->merchant_id ?></td>
                <td><?= $bankAccount->account_number ?></td>
                <td><?= $bankAccount->routing_number ?></td>
                <td><?= $bankAccount->ssn ?></td>
            <!--<td><a id="edit" href="{{ URL::Route('AdminBankProvider',$bankAccount->id) }}"><input type="button" class="btn btn-success" value="Edit"></a>-->
                <td>
                    <a id="delete" href="{{ URL::Route('DeleteBankProvider',$bankAccount->id) }}">
                        <input type="button" class="btn btn-danger" value="Delete"></a>
                </td>
            </tr>
            <?php $i++; } ?>
            <?php else : ?>
            <tr>
                <td colspan="5">No Records Found</td>
            </tr>
            <?php endif; ?>

            </tbody>
        </table>

    </div>


@stop
