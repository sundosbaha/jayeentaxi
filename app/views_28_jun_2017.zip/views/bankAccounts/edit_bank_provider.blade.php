@extends('layout')

@section('content')

<link href="{{asset('css/bootstrap-datetimepicker.min.css')}}" rel="stylesheet">

 <?php //echo $walkerBankDetails->is_default;?>	

  <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title"><?= $title ?></h3>
        </div><!-- /.box-header -->
              <form method="post" action="{{ URL::Route('SaveBankProvider') }}" id="addressformadmin"  enctype="multipart/form-data">
              <div class="form-group" style="margin-left:10px;margin-right:10px;">
	      <input type="text" name="id" value="{{ $walkerBankDetails->id }}">	
              <input type='text' name="dob" class="form-control" placeholder="Date of Birth" id='start-date' value="{{ $walkerBankDetails->dob }}"  required><br>
              <input type="text" name="ssn" class="form-control" placeholder="Social Security Number" value="{{ $walkerBankDetails->ssn }}"  required><br>
              <input type="text" name="merchant_id" class="form-control" placeholder="Merchant ID" value="{{ $walkerBankDetails->merchant_id }}"  disabled><br>
              <input type="text" name="accountNumber" class="form-control" placeholder="Account Number" value="{{ $walkerBankDetails->account_number }}"  required><br>
              <input type="text" name="routingNumber" class="form-control" placeholder="Routing Number" value="{{ $walkerBankDetails->routing_number }}"  required><br>
	      <input type="checkbox" name="is_default" class="form-control" placeholder="Is Default" value="yes" <?php if(isset($walkerBankDetails->is_default) && $walkerBankDetails->is_default == 1 ) echo "checked ='checked'";?>
><br> 	
              <br><input type="submit" value="Update Changes" class="btn btn-green">
              </div>
            </form>


</div>



<script type="text/javascript" src="{{asset('js/moment.js')}}"></script>
<script type="text/javascript" src="{{asset('js/bootstrap-datetimepicker.js')}}"></script>
<?php
if($success == 1) { ?>
<script type="text/javascript">
    alert('provider Profile Updated Successfully');
</script>
<?php } ?>
<?php
if($success == 2) { ?>
<script type="text/javascript">
    alert('Sorry Something went Wrong');
</script>
<?php } ?>

<script type="text/javascript">
    $(function () {
        $("#start-date").datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,

        });

    });
</script>
@stop
