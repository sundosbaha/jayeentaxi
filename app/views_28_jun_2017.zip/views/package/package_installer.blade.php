


<form action="#" method="post" enctype="multipart/form-data">
    <input name="zip_file" type="file">
    <input type="submit" name="submit"  value="submit">
</form>

